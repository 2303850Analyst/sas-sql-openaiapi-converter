// Copyright © 2024, SAS Institute Inc., Cary, NC, USA.  All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { Uri, l10n, window } from "vscode";

import { TableColumn } from "../components/LibraryNavigator/types";
import { TableInfo } from "../connection/rest/api/compute";
import { WebView } from "./WebviewManager";
import {
  extractFormatName,
  getIconLabel,
  iconForColumn,
} from "./columnIconClassifier";

class TablePropertiesViewer extends WebView {
  l10nMessages = undefined;

  constructor(
    extensionUri: Uri,
    private readonly tableName: string,
    private tableInfo: TableInfo,
    private columns: TableColumn[],
    private readonly showColumns: boolean = false,
    private readonly focusedColumn: string = "",
    private readonly refreshTableInfo: () => Promise<TableInfo>,
    private readonly refreshColumns: () => Promise<TableColumn[]>,
  ) {
    super(extensionUri, l10n.t("Table Properties"));
  }

  public body(): string {
    return `<div class="container">
      <h1>${l10n.t("Table: {tableName}", { tableName: this.tableName })}</h1>

      <div class="tabs">
        <button class="tab ${this.showColumns ? "" : "active"}" data-tab="properties">${l10n.t("General")}</button>
        <button class="tab ${this.showColumns ? "active" : ""}" data-tab="columns">${l10n.t("Columns")}</button>
      </div>

      <div id="properties" class="tab-content ${this.showColumns ? "" : "active"}">
        ${this.generatePropertiesContent()}
      </div>

      <div id="columns" class="tab-content ${this.showColumns ? "active" : ""}">
        ${this.generateColumnsContent()}
      </div>
    </div>`;
  }

  public scripts(): string[] {
    return ["TablePropertiesViewer.js"];
  }
  public styles(): string[] {
    return ["TablePropertiesViewer.css"];
  }

  public processMessage(): void {
    // No messages to process for this static viewer
  }

  public async refreshData() {
    try {
      const [tableInfo, columns] = await Promise.all([
        this.refreshTableInfo(),
        this.refreshColumns(),
      ]);
      this.tableInfo = tableInfo;
      this.columns = columns;
      this.render();
    } catch (error) {
      window.showErrorMessage(error.message);
    }
  }

  private generatePropertiesContent(): string {
    const formatValue = (value: unknown): string => {
      if (value === null || value === undefined) {
        return "";
      }
      if (typeof value === "number") {
        return value.toLocaleString();
      }
      return String(value);
    };

    const formatDate = (value: unknown): string => {
      try {
        const stringVal = String(value);
        let dateVal = new Date(stringVal);
        if (!isNaN(dateVal.getTime())) {
          return dateVal.toLocaleString();
        }

        const numVal = parseFloat(stringVal);
        if (numVal > 0) {
          // SAS datetime is seconds since 1960-01-01; subtract the offset of 315619200 seconds to shift to Unix epoch (1970-01-01), then multiply by 1000 for JavaScript milliseconds.
          dateVal = new Date((numVal - 315619200) * 1000);
          if (!isNaN(dateVal.getTime())) {
            return dateVal.toLocaleString();
          }
        }

        return stringVal;
      } catch {
        return String(value);
      }
    };

    return `
      <div class="section-title">${l10n.t("General Information")}</div>
      <table class="properties-table">
        <tr>
          <td class="property-label">${l10n.t("Name")}</td>
          <td>${formatValue(this.tableInfo.name)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Library")}</td>
          <td>${formatValue(this.tableInfo.libref)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Type")}</td>
          <td>${formatValue(this.tableInfo.type)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Label")}</td>
          <td>${formatValue(this.tableInfo.label)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Engine")}</td>
          <td>${formatValue(this.tableInfo.engine)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Extended Type")}</td>
          <td>${formatValue(this.tableInfo.extendedType)}</td>
        </tr>
      </table>

      <div class="section-title">${l10n.t("Size Information")}</div>
      <table class="properties-table">
        <tr>
          <td class="property-label">${l10n.t("Number of Rows")}</td>
          <td>${formatValue(this.tableInfo.rowCount)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Number of Columns")}</td>
          <td>${formatValue(this.tableInfo.columnCount)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Logical Record Count")}</td>
          <td>${formatValue(this.tableInfo.logicalRecordCount)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Physical Record Count")}</td>
          <td>${formatValue(this.tableInfo.physicalRecordCount)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Record Length")}</td>
          <td>${formatValue(this.tableInfo.recordLength)}</td>
        </tr>
      </table>

      <div class="section-title">${l10n.t("Technical Information")}</div>
      <table class="properties-table">
        <tr>
          <td class="property-label">${l10n.t("Created")}</td>
          <td>${formatDate(this.tableInfo.creationTimeStamp)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Modified")}</td>
          <td>${formatDate(this.tableInfo.modifiedTimeStamp)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Compression")}</td>
          <td>${formatValue(this.tableInfo.compressionRoutine)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Character Encoding")}</td>
          <td>${formatValue(this.tableInfo.encoding)}</td>
        </tr>
        <tr>
          <td class="property-label">${l10n.t("Bookmark Length")}</td>
          <td>${formatValue(this.tableInfo.bookmarkLength)}</td>
        </tr>
      </table>
    `;
  }

  private generateColumnsContent(): string {
    const getDisplayType = (type: string): string => {
      switch (type?.toUpperCase()) {
        case "CHAR":
        case "CHARACTER":
          return "Character";

        case "FLOAT":
        case "NUMERIC":
        case "NUM":
        case "CURRENCY":
        case "DATE":
        case "TIME":
        case "DATETIME":
          return "Numeric";

        default:
          return type;
      }
    };

    const formatValue = (value: unknown): string => {
      if (value === null || value === undefined) {
        return "";
      }
      return String(value);
    };

    const columnsRows = this.columns
      .map((column, index) => {
        const formatName = formatValue(extractFormatName(column.format));

        const columnType = formatValue(column.type);

        const nameIconClass = iconForColumn(columnType, column.formatCategory);

        const typeIconClass = iconForColumn(columnType);

        const nameIconTitle = getIconLabel(nameIconClass);

        const typeIconTitle = getIconLabel(typeIconClass);

        return `
      <tr class="${column.name === this.focusedColumn ? "active" : ""}">
        <td>${index + 1}</td>
        <td>
          <span
            class="header-icon ${nameIconClass}"
            title="${nameIconTitle}"
          ></span>
          ${column.name}
        </td>
        <td>
          <span
            class="header-icon ${typeIconClass}"
            title="${typeIconTitle}"
          ></span>
          ${getDisplayType(columnType)}
        </td>
        <td>${formatValue(column.length)}</td>
        <td>${formatName}</td>
        <td>${formatValue(extractFormatName(column.informat))}</td>
        <td>${formatValue(column.label)}</td>
      </tr>
      `;
      })
      .join("");

    return `
      <div class="section-title">${l10n.t("Columns ({count})", { count: this.columns.length })}</div>
      <table class="properties-table">
        <thead>
          <tr>
            <th>${l10n.t("#")}</th>
            <th>${l10n.t("Name")}</th>
            <th>${l10n.t("Type")}</th>
            <th>${l10n.t("Length")}</th>
            <th>${l10n.t("Format")}</th>
            <th>${l10n.t("Informat")}</th>
            <th>${l10n.t("Label")}</th>
          </tr>
        </thead>
        <tbody>
          ${columnsRows}
        </tbody>
      </table>
    `;
  }
}

export default TablePropertiesViewer;
