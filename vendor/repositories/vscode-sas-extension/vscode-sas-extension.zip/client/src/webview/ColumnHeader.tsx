// Copyright © 2025, SAS Institute Inc., Cary, NC, USA.  All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef } from "react";

import { AgColumn, GridApi } from "ag-grid-community";

import { getIconLabel, iconForColumn } from "../panels/columnIconClassifier";
import localize from "./localize";
import useTheme from "./useTheme";

const getTermForIcon = (icon: string) =>
  localize(getIconLabel(icon) || "Character");

const ColumnHeader = ({
  api,
  column,
  currentColumn: getCurrentColumn,
  columnType,
  columnFormatCategory,
  displayMenuForColumn,
}: {
  api: GridApi;
  column: AgColumn;
  currentColumn: () => AgColumn | undefined;
  columnType: string;
  columnFormatCategory?: string;
  displayMenuForColumn: (api: GridApi, column: AgColumn, rect: DOMRect) => void;
}) => {
  const theme = useTheme();
  const ref = useRef<HTMLButtonElement>(undefined!);
  const currentColumn = getCurrentColumn();
  const currentSortedColumns = api.getColumnState().filter((c) => c.sort);
  const sort = column.getSort();
  const columnNumber =
    sort && currentSortedColumns.length > 1 ? `${column.sortIndex + 1}` : "";
  const dropdownClassname =
    currentColumn?.colId === column.colId ? "active dropdown" : "dropdown";
  const sortTitle =
    sort === "asc"
      ? localize("Sorted, Ascending")
      : localize("Sorted, Descending");
  const columnIcon = iconForColumn(columnType, columnFormatCategory);

  const displayColumnMenu = () =>
    displayMenuForColumn(api, column, ref.current.getBoundingClientRect());

  return (
    <div className={`ag-cell-label-container ${theme}`} role="presentation">
      <div className="ag-header-cell-label" role="presentation">
        <span
          className={`header-icon ${columnIcon}`}
          title={getTermForIcon(columnIcon)}
        />
        <span className="ag-header-cell-text" title={column.colId}>
          {column.colId}
        </span>
        <span className="sort-icon-wrapper">
          {!!sort && (
            <>
              <span className={`icon ${sort}`} title={sortTitle}></span>
              {!!columnNumber && <span className="number">{columnNumber}</span>}
            </>
          )}
        </span>
        <div className={dropdownClassname}>
          <button
            ref={ref}
            type="button"
            onClick={displayColumnMenu}
            tabIndex={-1}
            title={localize("Options")}
          >
            <span />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColumnHeader;
