import {
  DataTransfer,
  DataTransferItem,
  FileStat,
  FileType,
  Tab,
  TabGroup,
  TabInputText,
  TextDocument,
  TreeItem,
  Uri,
  authentication,
  commands,
  window,
  workspace,
} from "vscode";

import axios, {
  AxiosHeaders,
  AxiosInstance,
  AxiosResponse,
  HeadersDefaults,
} from "axios";
import { expect } from "chai";
import { mkdtempSync, rmSync } from "fs";
import { tmpdir } from "os";
import { basename, join } from "path";
import * as sinon from "sinon";
import { StubbedInstance, stubInterface } from "ts-sinon";

import ContentDataProvider from "../../../src/components/ContentNavigator/ContentDataProvider";
import { ContentModel } from "../../../src/components/ContentNavigator/ContentModel";
import {
  FAVORITES_FOLDER_TYPE,
  FOLDER_SHORTCUTS,
  GLOBAL_SHORTCUT_TYPE,
  ROOT_FOLDER,
  ROOT_SHORTCUT_FOLDER_TYPE,
  SERVER_SHORTCUT_FOLDER_TYPE,
  TRASH_FOLDER_TYPE,
} from "../../../src/components/ContentNavigator/const";
import {
  ContentItem,
  ContentSourceType,
} from "../../../src/components/ContentNavigator/types";
import RestContentAdapter from "../../../src/connection/rest/RestContentAdapter";
import RestServerAdapter from "../../../src/connection/rest/RestServerAdapter";
import { FileSystemApi } from "../../../src/connection/rest/api/compute";
import { getSasContentUri as getUri } from "../../../src/connection/rest/util";
import { getUri as getTestUri } from "../../utils";

let axiosInstance: StubbedInstance<AxiosInstance>;

const defaultConfig = {
  mimeType: "application/vnd.code.tree.contentdataprovider",
  sourceType: ContentSourceType.SASContent,
  treeIdentifier: "contentdataprovider",
};

const mockContentItem = (
  initialContentItem: Partial<ContentItem> = {},
): ContentItem => {
  const contentItem = {
    id: "abc123",
    type: "file",
    fileStat: {
      type: FileType.File,
      ctime: 1234,
      mtime: 1234,
      size: 0,
    },
    creationTimeStamp: 1234,
    links: [
      {
        rel: "self",
        uri: "uri://self",
        method: "GET",
        href: "uri://self",
        type: "test",
      },
    ],
    modifiedTimeStamp: 1234,
    name: "testFile",
    uri: "uri://test",
    permission: {
      write: false,
      addMember: false,
      delete: false,
    },
    flags: {
      isInRecycleBin: false,
      isInMyFavorites: false,
    },
    uid: "unique-id",
    ...initialContentItem,
  };

  return {
    ...contentItem,
    vscUri: getUri(contentItem),
  };
};

const createDataProvider = () => {
  const adapter = new RestContentAdapter();
  const mockGetRootFolder = sinon.stub(adapter, "getRootFolder");
  mockGetRootFolder.withArgs("@myRecycleBin").returns(
    mockContentItem({
      type: "trashFolder",
      name: "Recycle Bin",
      links: [
        {
          rel: "self",
          uri: "uri://self",
          method: "GET",
          href: "uri://self",
          type: "test",
        },
      ],
      uri: "uri://recyleBin",
    }),
  );
  mockGetRootFolder.withArgs("@myFavorites").returns(
    mockContentItem({
      type: "favoritesFolder",
      name: "My Favorites",
      links: [
        {
          rel: "addMember",
          uri: "uri://addMember",
          method: "POST",
          href: "uri://addMember",
          type: "test",
        },
      ],
      uri: "uri://myFavorites",
    }),
  );

  return new ContentDataProvider(
    new ContentModel(adapter),
    Uri.from({ scheme: "http" }),
    defaultConfig,
  );
};

describe("ContentDataProvider", async function () {
  beforeEach(() => {
    sinon.stub(authentication, "getSession").resolves({
      accessToken: "12345",
      account: { id: "id", label: "label" },
      id: "id",
      scopes: [],
    });

    axiosInstance = stubInterface<AxiosInstance>();
    axiosInstance.interceptors.response = {
      use: () => null,
      eject: () => null,
      clear: () => null,
    };
    const defaultHeader: HeadersDefaults = {
      common: {
        Authorization: "",
      },
      put: {},
      post: {},
      patch: {},
      delete: {},
      head: {},
      get: {},
    };
    axiosInstance.defaults = {
      // eslint-disable-next-line @typescript-eslint/consistent-type-assertions
      headers: defaultHeader as AxiosInstance["defaults"]["headers"],
    };

    sinon.stub(axios, "create").returns(axiosInstance);
  });

  afterEach(() => {
    sinon.restore();
    axiosInstance = undefined;
  });

  it("getTreeItem - returns a file tree item for file reference", async () => {
    const contentItem: ContentItem = mockContentItem();
    const dataProvider = createDataProvider();

    const treeItem = await dataProvider.getTreeItem(contentItem);
    const uri = contentItem.vscUri;
    const expectedTreeItem: TreeItem = {
      id: "unique-id",
      label: "testFile",
      command: {
        command: "SAS.content.openResource",
        arguments: [contentItem],
        title: "Open SAS File",
      },
      resourceUri: uri,
    };

    expect(treeItem).to.deep.include(expectedTreeItem);
  });

  it("getTreeItem - returns a folder tree item for file reference", async () => {
    const contentItem: ContentItem = mockContentItem({
      type: "folder",
      name: "testFolder",
    });
    const dataProvider = createDataProvider();

    const treeItem = await dataProvider.getTreeItem(contentItem);
    const expectedTreeItem: TreeItem = {
      id: "unique-id",
      label: "testFolder",
    };

    expect(treeItem).to.deep.include(expectedTreeItem);
  });

  [
    { typeName: ROOT_SHORTCUT_FOLDER_TYPE, icon: "shortcutsFolder" },
    { typeName: SERVER_SHORTCUT_FOLDER_TYPE, icon: "shortcutsServerContent" },
    { typeName: GLOBAL_SHORTCUT_TYPE, icon: "webDAVRepository" },
  ].forEach(({ typeName, icon }) => {
    it(`getTreeItem - returns the ${icon} icon for a ${typeName} folder`, async () => {
      const contentItem: ContentItem = mockContentItem({
        type: typeName,
        typeName,
        name: "testShortcutFolder",
        fileStat: {
          type: FileType.Directory,
          ctime: 1234,
          mtime: 1234,
          size: 0,
        },
      });
      const dataProvider = createDataProvider();

      const treeItem = await dataProvider.getTreeItem(contentItem);

      const extensionUri = Uri.from({ scheme: "http" });
      expect(treeItem.iconPath).to.deep.equal({
        dark: Uri.joinPath(extensionUri, `icons/dark/${icon}Dark.svg`),
        light: Uri.joinPath(extensionUri, `icons/light/${icon}Light.svg`),
      });
    });
  });

  it("getChildren - returns no children if not authorized", async () => {
    const dataProvider = createDataProvider();
    const children = await dataProvider.getChildren();
    expect(children.length).to.equal(0);
  });

  it("getChildren - returns root children without content item", async function () {
    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("/folders/folders/@myFavorites").resolves({
      data: mockContentItem({
        name: "@myFavorites",
        type: "folder",
      }),
    });

    axiosInstance.get.withArgs("/folders/folders/@myFolder").resolves({
      data: mockContentItem({
        name: "@myFolder",
        type: "folder",
      }),
    });

    axiosInstance.get.withArgs("/folders/folders/@myRecycleBin").resolves({
      data: mockContentItem({
        name: "@myRecycleBin",
        type: "folder",
      }),
    });

    await dataProvider.connect("http://test.io");

    const children = await dataProvider.getChildren();
    expect(children.length).to.equal(5);
    expect(children[0].name).to.equal("@myFavorites");
    expect(children[1].name).to.equal("@myFolder");
    expect(children[2].name).to.equal(FOLDER_SHORTCUTS.name);
    expect(children[3].name).to.equal(ROOT_FOLDER.name);
    expect(children[4].name).to.equal("@myRecycleBin");
  });

  it("getChildren - returns children with content item", async function () {
    const childItem = mockContentItem({
      flags: {
        isInMyFavorites: true,
        isInRecycleBin: false,
      },
      uid: "my-favorite/0",
    });
    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("/deploymentData/cadenceVersion").resolves({
      data: { cadenceVersion: "2023.07" },
    });

    axiosInstance.get
      .withArgs(
        "uri://myFavorites?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','rootShortcutFolder','serverShortcutFolder','globalShortcutfolder','shortcutsFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({
        data: {
          items: [childItem],
        },
      });

    await dataProvider.connect("http://test.io");

    const children = await dataProvider.getChildren(
      mockContentItem({
        name: "@myFavorites",
        type: "folder",
        links: [
          {
            rel: "members",
            uri: "uri://myFavorites",
            method: "GET",
            href: "uri://@myFavorites",
            type: "test",
          },
        ],
        uri: "uri://myFavorites",
        uid: "my-favorite",
      }),
    );

    expect(children.length).to.equal(1);
    expect(children[0]).to.deep.include(childItem);
  });

  it("stat - returns file data", async function () {
    const childItem = mockContentItem();
    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("uri://test").resolves({
      data: childItem,
      headers: { etag: "1234", "last-modified": "5678" },
    });

    await dataProvider.connect("http://test.io");
    const fileData: FileStat = await dataProvider.stat(getUri(childItem));

    expect(fileData).to.deep.include({
      type: FileType.File,
      ctime: 1234,
      mtime: 1234,
      size: 0,
    });
  });

  it("stat - returns folder data", async function () {
    const childItem = mockContentItem({ type: "folder" });
    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("uri://test").resolves({
      data: childItem,
      headers: { etag: "1234", "last-modified": "5678" },
    });

    await dataProvider.connect("http://test.io");
    const folderData: FileStat = await dataProvider.stat(getUri(childItem));

    expect(folderData).to.deep.include({
      type: FileType.Directory,
      ctime: 1234,
      mtime: 1234,
      size: 0,
    });
  });

  it("readFile - returns file contents", async function () {
    const childItem = mockContentItem();
    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("uri://test/content").resolves({
      data: new TextEncoder().encode("/* file content */"),
      headers: { etag: "1234", "last-modified": "5678" },
    });

    await dataProvider.connect("http://test.io");
    const fileData: Uint8Array = await dataProvider.readFile(getUri(childItem));

    expect(new TextDecoder().decode(fileData)).to.equal("/* file content */");
  });

  it("createFolder - creates a folder", async function () {
    const parentItem = mockContentItem({
      type: "folder",
      uri: "uri://parent-folder",
    });
    const createdFolder = mockContentItem({
      type: "folder",
      name: "folder-test",
    });
    const dataProvider = createDataProvider();

    axiosInstance.post
      .withArgs("/folders/folders?parentFolderUri=uri://parent-folder", {
        name: "folder-test",
      })
      .resolves({
        data: createdFolder,
      });

    await dataProvider.connect("http://test.io");
    const uri: Uri = await dataProvider.createFolder(parentItem, "folder-test");
    expect(uri).to.deep.equal(getUri(createdFolder));
  });

  it("createFolder - fails to create a folder without parent folder", async function () {
    const parentItem = mockContentItem({ type: "folder", uri: "" });
    const dataProvider = createDataProvider();

    const item = await dataProvider.createFolder(parentItem, "folder-test");

    expect(item).to.equal(undefined);
  });

  it("createFile - creates a file and adds it to a folder", async function () {
    const parentItem = mockContentItem({
      type: "folder",
      uri: "uri://parent-folder",
      links: [
        {
          rel: "addMember",
          uri: "uri://addMember",
          method: "POST",
          href: "uri://addMember",
          type: "test",
        },
      ],
    });
    const createdFile = mockContentItem({
      type: "file",
      name: "file.sas",
    });

    const dataProvider = createDataProvider();

    axiosInstance.post
      .withArgs(
        "/files/files#rawUpload?typeDefName=programFile",
        Buffer.from("", "binary"),
      )
      .resolves({
        data: createdFile,
      });

    axiosInstance.post
      .withArgs("uri://addMember", {
        uri: "uri://self",
        type: "CHILD",
        name: "file.sas",
        contentType: "programFile",
      })
      .resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const uri: Uri = await dataProvider.createFile(parentItem, "file.sas");
    expect(uri).to.deep.equal(getUri(createdFile));
  });

  it("renameResource - fail if the new name is conflicted", async function () {
    const origItem = mockContentItem({
      type: "file",
      name: "file.sas",
      uri: "uri://rename",
      links: [
        {
          method: "PUT",
          rel: "validateRename",
          uri: "uri://validate?value={newname}&type={newtype}",
          href: "uri://validate?value={newname}&type={newtype}",
          type: "test",
        },
      ],
    });

    axiosInstance.get.withArgs("uri://rename").resolves({
      data: origItem,
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.put
      .withArgs("uri://validate?value=new-file.sas&type=file")
      .rejects({
        data: {
          status: 409,
        },
      });
    axiosInstance.get
      .withArgs(
        "uri://myFavorites/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: { items: [] } });
    axiosInstance.get
      .withArgs(
        "uri://test/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: [] });

    const dataProvider = createDataProvider();

    await dataProvider.connect("http://test.io");
    const uri: Uri = await dataProvider.renameResource(
      origItem,
      "new-file.sas",
    );
    expect(uri).to.equal(undefined);
  });

  it("renameResource - renames resource and returns uri", async function () {
    const origItem = mockContentItem({
      type: "file",
      name: "file.sas",
      uri: "uri://rename",
    });

    const newItem = mockContentItem({
      type: "file",
      name: "new-file.sas",
      uri: "uri://rename",
    });

    axiosInstance.get.withArgs("uri://rename").resolves({
      data: origItem,
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.put.withArgs("uri://rename").resolves({
      data: { ...origItem, name: "new-file.sas" },
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.get
      .withArgs(
        "uri://myFavorites/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: { items: [] } });
    axiosInstance.get
      .withArgs(
        "uri://rename/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: { items: [] } });

    const dataProvider = createDataProvider();

    await dataProvider.connect("http://test.io");
    const uri: Uri = await dataProvider.renameResource(
      origItem,
      "new-file.sas",
    );

    expect(uri).to.deep.equal(getUri(newItem));
  });

  it("renameResource - renames reference resource and returns uri of referenced item", async function () {
    const item = mockContentItem({
      type: "reference",
      name: "favorite-link.sas",
      uri: "uri://rename",
    });

    const referencedFile = mockContentItem({
      type: "file",
      name: "the-real-file.sas",
    });

    const dataProvider = createDataProvider();

    axiosInstance.get.withArgs("uri://self").resolves({
      data: item,
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.put.withArgs("uri://self").resolves({
      data: { ...item, name: "favorite-link.sas" },
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.get.withArgs("uri://rename").resolves({
      data: referencedFile,
      headers: { etag: "1234", "last-modified": "5678" },
    });
    axiosInstance.get
      .withArgs(
        "uri://myFavorites/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: { items: [] } });
    axiosInstance.get
      .withArgs(
        "uri://test/members?limit=1000000&filter=in(contentType,'file','dataFlow','RootFolder','folder','myFolder','favoritesFolder','userFolder','userRoot','trashFolder')&sortBy=eq(contentType,'folder'):descending,name:primary:ascending,type:ascending",
      )
      .resolves({ data: { items: [] } });

    await dataProvider.connect("http://test.io");
    const uri: Uri = await dataProvider.renameResource(
      item,
      "favorite-link.sas",
    );

    expect(uri).to.deep.equal(getUri(referencedFile));
  });

  it("writeFile - saves text based content to file", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
    });

    const dataProvider = createDataProvider();

    // Make initial request and store file token data
    axiosInstance.get.withArgs("uri://test/content").resolves({
      data: "/* file content */",
      headers: { etag: "1234", "last-modified": "5678" },
    });

    await dataProvider.connect("http://test.io");

    axiosInstance.put
      .withArgs("uri://test/content", "/* This is the content */")
      .resolves({
        data: item,
        headers: { etag: "1234", "last-modified": "5678" },
      });

    await dataProvider.connect("http://test.io");
    await dataProvider.writeFile(
      getUri(item),
      new TextEncoder().encode("/* This is the content */"),
    );
  });

  it("delete - deletes item and underlying resource", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      links: [
        {
          rel: "delete",
          uri: "uri://delete",
          method: "DELETE",
          href: "uri://delete",
          type: "test",
        },
        {
          rel: "deleteResource",
          uri: "uri://delete-resource",
          method: "DELETE",
          href: "uri://delete-resource",
          type: "test",
        },
      ],
    });

    const dataProvider = createDataProvider();

    axiosInstance.delete.withArgs("uri://delete").resolves({ data: {} });
    axiosInstance.delete
      .withArgs("uri://delete-resource")
      .resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const deleted = await dataProvider.deleteResource(item);

    expect(deleted).to.equal(true);
  });

  it("recycleResource - move item to the recycle bin", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      links: [
        {
          rel: "update",
          uri: "uri://update",
          method: "PUT",
          href: "uri://update",
          type: "test",
        },
      ],
    });
    const dataProvider = createDataProvider();

    axiosInstance.put.withArgs("uri://update").resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const recycled = await dataProvider.recycleResource(item);

    expect(recycled).to.equal(true);
  });

  it("recycleResource - closes direct and nested descendant tabs", async function () {
    const folder = mockContentItem({
      fileStat: {
        type: FileType.Directory,
        ctime: 1234,
        mtime: 1234,
        size: 0,
      },
      name: "testD",
      type: "folder",
      uri: "uri://testD",
      links: [
        {
          rel: "update",
          uri: "uri://update-folder",
          method: "PUT",
          href: "uri://update-folder",
          type: "test",
        },
      ],
    });
    const nestedFolder = mockContentItem({
      fileStat: {
        type: FileType.Directory,
        ctime: 1234,
        mtime: 1234,
        size: 0,
      },
      name: "nested",
      type: "folder",
      uri: "uri://nested",
      parentFolderUri: folder.uri,
    });
    const directFile = mockContentItem({
      name: "test1.sas",
      uri: "uri://test1",
      parentFolderUri: folder.uri,
    });
    const nestedFile = mockContentItem({
      name: "test2.sas",
      uri: "uri://test2",
      parentFolderUri: nestedFolder.uri,
    });
    sinon
      .stub(ContentModel.prototype, "getChildren")
      .callsFake(async (item) => {
        if (item?.uri === folder.uri) {
          return [directFile, nestedFolder];
        }
        if (item?.uri === nestedFolder.uri) {
          return [nestedFile];
        }
        return [];
      });

    const directDocument = stubInterface<TextDocument>();
    Object.defineProperty(directDocument, "uri", {
      value: getUri(directFile),
    });
    Object.defineProperty(directDocument, "isDirty", { value: true });
    const nestedDocument = stubInterface<TextDocument>();
    Object.defineProperty(nestedDocument, "uri", {
      value: getUri(nestedFile),
    });
    Object.defineProperty(nestedDocument, "isDirty", { value: true });
    sinon
      .stub(workspace, "textDocuments")
      .value([directDocument, nestedDocument]);

    const directTab = stubInterface<Tab>();
    Object.defineProperty(directTab, "input", {
      value: new TabInputText(getUri(directFile)),
    });
    const nestedTab = stubInterface<Tab>();
    Object.defineProperty(nestedTab, "input", {
      value: new TabInputText(getUri(nestedFile)),
    });
    const unrelatedTab = stubInterface<Tab>();
    Object.defineProperty(unrelatedTab, "input", {
      value: new TabInputText(getUri(mockContentItem({ uri: "uri://other" }))),
    });
    const tabs = [directTab, nestedTab, unrelatedTab];
    const tabGroup = stubInterface<TabGroup>();
    Object.defineProperty(tabGroup, "tabs", { value: tabs });
    const originalTabGroupsDescriptor = Object.getOwnPropertyDescriptor(
      window,
      "tabGroups",
    );
    Object.defineProperty(window, "tabGroups", {
      configurable: true,
      value: { all: [tabGroup] },
    });
    sinon.stub(window, "showTextDocument").resolves(undefined);
    const executeCommandStub = sinon
      .stub(commands, "executeCommand")
      .callsFake(async (command) => {
        if (command === "workbench.action.revertAndCloseActiveEditor") {
          tabs.shift();
        }
      });

    const dataProvider = createDataProvider();

    axiosInstance.put.withArgs("uri://update-folder").resolves({ data: {} });

    try {
      await dataProvider.connect("http://test.io");
      const recycled = await dataProvider.recycleResource(folder);

      expect(recycled).to.equal(true);
      expect(
        executeCommandStub.withArgs(
          "workbench.action.revertAndCloseActiveEditor",
        ).callCount,
      ).to.equal(2);
      expect(tabs).to.deep.equal([unrelatedTab]);
    } finally {
      if (originalTabGroupsDescriptor) {
        Object.defineProperty(window, "tabGroups", originalTabGroupsDescriptor);
      }
    }
  });

  it("recycleResource - discards and closes dirty descendant tabs", async function () {
    const folder = mockContentItem({
      fileStat: {
        type: FileType.Directory,
        ctime: 1234,
        mtime: 1234,
        size: 0,
      },
      name: "NotEmptyFolder",
      type: "folder",
      uri: "uri://NotEmptyFolder",
      links: [
        {
          rel: "update",
          uri: "uri://update-dirty-folder",
          method: "PUT",
          href: "uri://update-dirty-folder",
          type: "test",
        },
      ],
    });
    const file = mockContentItem({
      name: "docForDelete.sas",
      uri: "uri://docForDelete",
      parentFolderUri: folder.uri,
    });
    sinon.stub(ContentModel.prototype, "getChildren").resolves([file]);

    const dirtyDocument = stubInterface<TextDocument>();
    Object.defineProperty(dirtyDocument, "uri", { value: getUri(file) });
    Object.defineProperty(dirtyDocument, "isDirty", { value: true });
    sinon.stub(workspace, "textDocuments").value([dirtyDocument]);

    const dirtyTab = stubInterface<Tab>();
    Object.defineProperty(dirtyTab, "input", {
      value: new TabInputText(getUri(file)),
    });
    const tabs = [dirtyTab];
    const tabGroup = stubInterface<TabGroup>();
    Object.defineProperty(tabGroup, "tabs", { value: tabs });
    const originalTabGroupsDescriptor = Object.getOwnPropertyDescriptor(
      window,
      "tabGroups",
    );
    Object.defineProperty(window, "tabGroups", {
      configurable: true,
      value: { all: [tabGroup] },
    });
    sinon.stub(window, "showTextDocument").resolves(undefined);
    const executeCommandStub = sinon
      .stub(commands, "executeCommand")
      .callsFake(async (command) => {
        if (command === "workbench.action.revertAndCloseActiveEditor") {
          tabs.splice(0, 1);
        }
      });

    const dataProvider = createDataProvider();
    axiosInstance.put
      .withArgs("uri://update-dirty-folder")
      .resolves({ data: {} });

    try {
      await dataProvider.connect("http://test.io");
      const recycled = await dataProvider.recycleResource(folder);

      expect(recycled).to.equal(true);
      expect(
        executeCommandStub.calledWith(
          "workbench.action.revertAndCloseActiveEditor",
        ),
      ).to.equal(true);
      expect(tabs).to.have.length(0);
    } finally {
      if (originalTabGroupsDescriptor) {
        Object.defineProperty(window, "tabGroups", originalTabGroupsDescriptor);
      }
    }
  });

  it("restoreResource - restore item to the previous parent folder", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      links: [
        {
          rel: "update",
          uri: "uri://update",
          method: "PUT",
          href: "uri://update",
          type: "test",
        },
        {
          rel: "previousParent",
          uri: "uri://previous.parent",
          method: "GET",
          href: "previousParent",
          type: "test",
        },
      ],
    });

    const dataProvider = createDataProvider();

    axiosInstance.put.withArgs("uri://update").resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const deleted = await dataProvider.restoreResource(item);

    expect(deleted).to.equal(true);
  });

  it("add to favorites - Add the reference of an item to My Favorites folder", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      links: [
        {
          rel: "getResource",
          uri: "uri://resource",
          method: "GET",
          href: "uri://resource",
          type: "test",
        },
      ],
    });

    const dataProvider = createDataProvider();

    axiosInstance.post.withArgs("uri://addMember").resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const success = await dataProvider.addToMyFavorites(item);

    expect(success).to.equal(true);
  });

  it("remove from favorites - Remove the reference of an item from the resource", async function () {
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      flags: {
        favoriteUri: "uri://myFavorites/members/favorite-id",
      },
    });
    const dataProvider = createDataProvider();

    axiosInstance.get.resolves({ data: { items: [item] } });
    axiosInstance.delete
      .withArgs("uri://myFavorites/members/favorite-id")
      .resolves({ data: {} });

    await dataProvider.connect("http://test.io");
    const success = await dataProvider.removeFromMyFavorites(item);

    expect(success).to.equal(true);
  });

  it("handleDrop - allows dropping files", async function () {
    const parentItem = mockContentItem({
      type: "folder",
      name: "parent",
    });

    const uri = getTestUri("SampleCode.sas").toString();
    const item = mockContentItem();

    const model = new ContentModel(new RestContentAdapter());
    const stub: sinon.SinonStub = sinon.stub(model, "createFile");

    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    const dataTransfer = new DataTransfer();
    const dataTransferItem = new DataTransferItem(uri);
    dataTransfer.set("text/uri-list", dataTransferItem);

    stub.returns(new Promise((resolve) => resolve(item)));

    await dataProvider.handleDrop(parentItem, dataTransfer);

    expect(stub.calledOnceWith(parentItem, "SampleCode.sas")).to.be.true;
  });

  it("handleDrop - allows dropping folder", async function () {
    const parentItem = mockContentItem({
      type: "folder",
      name: "parent",
    });
    const newParentItem = mockContentItem({
      type: "folder",
      name: "new-parent",
    });

    const uriObject = getTestUri("TestFolder");
    const uri = uriObject.toString();
    const item = mockContentItem();

    const model = new ContentModel(new RestContentAdapter());
    const createFileStub: sinon.SinonStub = sinon.stub(model, "createFile");
    const createFolderStub: sinon.SinonStub = sinon.stub(model, "createFolder");

    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    const dataTransfer = new DataTransfer();
    const dataTransferItem = new DataTransferItem(uri);
    dataTransfer.set("text/uri-list", dataTransferItem);

    createFileStub.returns(new Promise((resolve) => resolve(item)));
    createFolderStub.returns(new Promise((resolve) => resolve(newParentItem)));

    await dataProvider.handleDrop(parentItem, dataTransfer);

    expect(createFolderStub.calledWith(parentItem, "TestFolder")).to.be.true;
    expect(createFileStub.calledWith(newParentItem, "SampleCode1.sas")).to.be
      .true;
    expect(createFolderStub.calledWith(newParentItem, "TestSubFolder")).to.be
      .true;
    expect(createFileStub.calledWith(newParentItem, "SampleCode2.sas")).to.be
      .true;
  });

  it("uploadUrisToTarget - refreshes tree for empty folder upload", async function () {
    const parentItem = mockContentItem({
      type: "folder",
      name: "parent",
    });
    const createdFolder = mockContentItem({
      type: "folder",
      name: "uploaded-empty-folder",
    });

    const dataProvider = createDataProvider();
    const emptyFolderPath = mkdtempSync(join(tmpdir(), "sas-empty-folder-"));
    const folderName = basename(emptyFolderPath);

    const refreshStub = sinon.stub(dataProvider, "refresh");
    const handleCreationResponseStub = sinon
      .stub(dataProvider, "handleCreationResponse")
      .resolves();
    const createFolderStub = sinon
      .stub(ContentModel.prototype, "createFolder")
      .resolves(createdFolder);

    try {
      await dataProvider.uploadUrisToTarget(
        [Uri.file(emptyFolderPath)],
        parentItem,
      );

      expect(createFolderStub.calledOnceWith(parentItem, folderName)).to.be
        .true;
      expect(refreshStub.calledOnce).to.be.true;
      expect(handleCreationResponseStub.calledOnce).to.be.true;
    } finally {
      createFolderStub.restore();
      rmSync(emptyFolderPath, { recursive: true, force: true });
    }
  });

  it("handleDrop - allows dropping content items", async function () {
    const parentItem = mockContentItem({
      name: "parent",
      resourceId: "/resource-id",
      type: "folder",
    });
    const item = mockContentItem();

    const model = new ContentModel(new RestContentAdapter());
    const stub: sinon.SinonStub = sinon.stub(model, "moveTo");
    stub.returns(new Promise((resolve) => resolve(true)));

    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    const dataTransfer = new DataTransfer();
    const dataTransferItem = new DataTransferItem([item]);
    dataTransfer.set(
      "application/vnd.code.tree.contentdataprovider",
      dataTransferItem,
    );

    await dataProvider.handleDrop(parentItem, dataTransfer);

    expect(stub.calledWith(item, "/resource-id")).to.be.true;
  });

  it("handleDrop - allows dropping content items to favorites", async function () {
    const parentItem = mockContentItem({
      type: FAVORITES_FOLDER_TYPE,
      name: "favorites",
      links: [
        {
          rel: "addMember",
          uri: "uri://addfav",
          method: "POST",
          href: "uri://addfav",
          type: "test",
        },
      ],
    });
    const item = mockContentItem({
      uri: "uri://favitem",
      links: [
        {
          rel: "getResource",
          uri: "uri://favitem",
          method: "GET",
          href: "uri://favitem",
          type: "test",
        },
      ],
    });

    const adapter = new RestContentAdapter();
    const model = new ContentModel(adapter);
    const stub: sinon.SinonStub = sinon.stub(adapter, "addChildItem");
    stub.returns(new Promise((resolve) => resolve(true)));

    sinon.stub(adapter, "getRootFolder").returns(parentItem);

    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    const dataTransfer = new DataTransfer();
    const dataTransferItem = new DataTransferItem([item]);
    dataTransfer.set(
      "application/vnd.code.tree.contentdataprovider",
      dataTransferItem,
    );

    await dataProvider.handleDrop(parentItem, dataTransfer);

    expect(stub.calledWith("uri://favitem", "uri://addfav")).to.be.true;
  });

  it("handleDrop - allows dropping content items to trash", async function () {
    const parentItem = mockContentItem({
      type: TRASH_FOLDER_TYPE,
      name: "trash",
      links: [
        {
          rel: "self",
          uri: "uri://trash",
          method: "GET",
          href: "uri://trash",
          type: "test",
        },
      ],
    });
    const item = mockContentItem();

    const adapter = new RestContentAdapter();
    const model = new ContentModel(adapter);
    const stub: sinon.SinonStub = sinon.stub(model, "recycleResource");
    stub.returns(
      new Promise((resolve) => resolve({ newUri: "new", oldUri: "old" })),
    );

    sinon.stub(adapter, "getRootFolder").returns(parentItem);

    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    const dataTransfer = new DataTransfer();
    const dataTransferItem = new DataTransferItem([item]);
    dataTransfer.set(
      "application/vnd.code.tree.contentdataprovider",
      dataTransferItem,
    );

    await dataProvider.handleDrop(parentItem, dataTransfer);

    expect(stub.calledWith(item)).to.be.true;
  });

  it("getFileFolderPath - returns empty path for folder", async function () {
    const item = mockContentItem({
      type: "folder",
      name: "folder",
    });

    const model = new ContentModel(new RestContentAdapter());
    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    await dataProvider.connect("http://test.io");
    const path = await model.getFileFolderPath(item);

    expect(path).to.equal("");
  });

  it("getFileFolderPath - traverses parentFolderUri to find path", async function () {
    const grandparent = mockContentItem({
      type: "folder",
      name: "grandparent",
      id: "/id/grandparent",
    });
    const parent = mockContentItem({
      type: "folder",
      name: "parent",
      id: "/id/parent",
      parentFolderUri: "/id/grandparent",
    });
    const item = mockContentItem({
      type: "file",
      name: "file.sas",
      parentFolderUri: "/id/parent",
    });
    const item2 = mockContentItem({
      type: "file",
      name: "file2.sas",
      parentFolderUri: "/id/parent",
    });

    const model = new ContentModel(new RestContentAdapter());
    const dataProvider = new ContentDataProvider(
      model,
      Uri.from({ scheme: "http" }),
      defaultConfig,
    );

    axiosInstance.get.withArgs("/id/parent").resolves({
      data: parent,
    });
    axiosInstance.get.withArgs("/id/grandparent").resolves({
      data: grandparent,
    });

    await dataProvider.connect("http://test.io");

    // We expect both files to have the same folder path
    expect(await model.getFileFolderPath(item)).to.equal("/grandparent/parent");
    expect(await model.getFileFolderPath(item2)).to.equal(
      "/grandparent/parent",
    );
  });
});

// showHiddenItems (Issue #1511)

const SERVER_SESSION_ID = "test-session-id";

const selfLinkFor = (name: string) => [
  {
    method: "GET",
    rel: "self",
    href: `/id/${name}`,
    uri: `/compute/sessions/${SERVER_SESSION_ID}/files/parent-folder/${name}`,
    type: "test",
  },
];

const mockFileProperties = (overrides: Record<string, unknown> = {}) => ({
  links: selfLinkFor("child.sas"),
  name: "child.sas",
  type: "file",
  modifiedTimeStamp: "2024-01-01T00:00:00Z",
  readOnly: false,
  isDirectory: false,
  ...overrides,
});

const mockAxiosResponse = <T>(data: T): AxiosResponse<T> => ({
  data,
  status: 200,
  statusText: "OK",
  headers: {},
  config: { headers: new AxiosHeaders() },
});

class TestableRestServerAdapter extends RestServerAdapter {
  public setFileSystemApiForTest(
    fileSystemApi: ReturnType<typeof FileSystemApi>,
  ): void {
    this.fileSystemApi = fileSystemApi;
  }

  public setSessionIdForTest(sessionId: string): void {
    this.sessionId = sessionId;
  }
}

describe("RestServerAdapter - getChildItems (showHiddenItems)", function () {
  const buildAdapter = (
    display?: { showHiddenItems?: boolean } | null,
  ): TestableRestServerAdapter => {
    const adapter = new TestableRestServerAdapter(
      undefined, // fileNavigationCustomRootPath
      "USER", // fileNavigationRoot
      {}, // globalShortcuts
      display,
    );
    adapter.setSessionIdForTest(SERVER_SESSION_ID);
    return adapter;
  };

  const buildFileSystemApiStub = (): StubbedInstance<
    ReturnType<typeof FileSystemApi>
  > => stubInterface<ReturnType<typeof FileSystemApi>>();

  const buildParentItem = (): ContentItem =>
    mockContentItem({
      id: "/id/parent-folder",
      uid: "parent-uid",
      type: "folder",
      uri: `/compute/sessions/${SERVER_SESSION_ID}/files/parent-folder`,
      links: [
        {
          rel: "getDirectoryMembers",
          uri: `/compute/sessions/${SERVER_SESSION_ID}/files/parent-folder/members`,
          method: "GET",
          href: `/compute/sessions/${SERVER_SESSION_ID}/files/parent-folder/members`,
          type: "test",
        },
      ],
    });

  const emptyResponse = () => mockAxiosResponse({ count: 0, items: [] });

  it("passes showAll: true when display.showHiddenItems is true", async () => {
    const adapter = buildAdapter({ showHiddenItems: true });
    const fileSystemApi = buildFileSystemApiStub();
    fileSystemApi.getDirectoryMembers.resolves(emptyResponse());
    adapter.setFileSystemApiForTest(fileSystemApi);

    await adapter.getChildItems(buildParentItem());

    expect(fileSystemApi.getDirectoryMembers.calledOnce).to.be.true;
    expect(fileSystemApi.getDirectoryMembers.firstCall.args[0]).to.deep.equal({
      sessionId: SERVER_SESSION_ID,
      directoryPath: "parent-folder",
      limit: 100,
      start: 0,
      showAll: true,
    });
  });

  it("passes showAll: false when display.showHiddenItems is explicitly false", async () => {
    const adapter = buildAdapter({ showHiddenItems: false });
    const fileSystemApi = buildFileSystemApiStub();
    fileSystemApi.getDirectoryMembers.resolves(emptyResponse());
    adapter.setFileSystemApiForTest(fileSystemApi);

    await adapter.getChildItems(buildParentItem());

    expect(fileSystemApi.getDirectoryMembers.firstCall.args[0]).to.deep.include(
      { showAll: false },
    );
  });

  it("defaults showAll to false when display is undefined", async () => {
    const adapter = buildAdapter(undefined);
    const fileSystemApi = buildFileSystemApiStub();
    fileSystemApi.getDirectoryMembers.resolves(emptyResponse());
    adapter.setFileSystemApiForTest(fileSystemApi);

    await adapter.getChildItems(buildParentItem());

    expect(fileSystemApi.getDirectoryMembers.firstCall.args[0]).to.deep.include(
      { showAll: false },
    );
  });

  it("defaults showAll to false when display is an empty object", async () => {
    const adapter = buildAdapter({});
    const fileSystemApi = buildFileSystemApiStub();
    fileSystemApi.getDirectoryMembers.resolves(emptyResponse());
    adapter.setFileSystemApiForTest(fileSystemApi);

    await adapter.getChildItems(buildParentItem());

    expect(fileSystemApi.getDirectoryMembers.firstCall.args[0]).to.deep.include(
      { showAll: false },
    );
  });

  it("does not throw and defaults showAll to false when display is null", async () => {
    const adapter = buildAdapter(null);
    const fileSystemApi = buildFileSystemApiStub();
    fileSystemApi.getDirectoryMembers.resolves(emptyResponse());
    adapter.setFileSystemApiForTest(fileSystemApi);

    await adapter.getChildItems(buildParentItem());

    expect(fileSystemApi.getDirectoryMembers.firstCall.args[0]).to.deep.include(
      { showAll: false },
    );
  });

  it("includes hidden items in the returned list when showHiddenItems is true", async () => {
    const adapter = buildAdapter({ showHiddenItems: true });
    const fileSystemApi = buildFileSystemApiStub();
    const hiddenFile = mockFileProperties({
      name: ".hidden-file.sas",
      links: selfLinkFor(".hidden-file.sas"),
    });
    const visibleFile = mockFileProperties({
      name: "visible.sas",
      links: selfLinkFor("visible.sas"),
    });
    fileSystemApi.getDirectoryMembers.resolves(
      mockAxiosResponse({ count: 2, items: [hiddenFile, visibleFile] }),
    );
    adapter.setFileSystemApiForTest(fileSystemApi);

    const children = await adapter.getChildItems(buildParentItem());
    const names = children.map((child) => child.name);

    expect(children.length).to.equal(2);
    expect(names).to.include(".hidden-file.sas");
    expect(names).to.include("visible.sas");
  });
});
