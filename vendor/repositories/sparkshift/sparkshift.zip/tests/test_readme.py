"""Keep the examples in the README and the guides identical to what SparkShift
actually produces."""

import io
import sys
from pathlib import Path

import pytest

import sparkshift
from sparkshift.cli import main

ROOT = Path(__file__).parents[1]
README = (ROOT / "README.md").read_text()
CLI_GUIDE = (ROOT / "docs" / "cli.md").read_text()


def test_usage_example_output_matches_real_output() -> None:
    sql = "SELECT order_id, amount * 1.10 AS with_tax FROM sales.orders"

    assert f'"{sql}"' in README
    assert f"```python\n{sparkshift.convert(sql).code}```" in README


def test_command_line_example_matches_real_output(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    sql = "SELECT TOP 3 name FROM customers ORDER BY name"
    monkeypatch.setattr(sys, "stdin", io.StringIO(sql))

    assert main(["convert", "-", "--dialect", "tsql"]) == 0

    command = f'echo "{sql}" | sparkshift convert - --dialect tsql'
    output = f"```python\n{capsys.readouterr().out}```"
    for document in (README, CLI_GUIDE):
        assert command in document
        assert output in document


def test_coverage_report_example_matches_real_output(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.chdir(Path(__file__).parents[1])

    assert main(["report", "examples/coverage"]) == 0

    assert "sparkshift report examples/coverage\n" in CLI_GUIDE
    assert f"```text\n{capsys.readouterr().out}```" in CLI_GUIDE


def test_sas_example_matches_real_output() -> None:
    program = (
        "data low_scores;\n"
        "    set customers (keep=customer_id name score);\n"
        "    where score < 3;\n"
        "    rename name = customer_name;\n"
        "run;\n"
    )

    assert f"```sas\n{program}```" in README
    code = sparkshift.convert(program, dialect="sas").code
    assert f"```python\n{code}```" in README


def test_unsupported_example_matches_real_error() -> None:
    with pytest.raises(sparkshift.UnsupportedSQLError) as caught:
        sparkshift.convert(
            "SELECT name, my_udf(score) AS s FROM customers LIMIT 10 OFFSET 20"
        )

    assert f"UnsupportedSQLError: {caught.value}" in README
