"""Tests for the command line, used exactly as a shell user would."""

import importlib
import io
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
from collections.abc import Callable
from pathlib import Path

import pytest

import sparkshift
from sparkshift.cli import EXIT_CONVERTED, EXIT_NOT_CONVERTED, EXIT_USAGE, main
from sparkshift.diagnostics import ConversionResult, Diagnostic
from sparkshift.report import (
    Report,
    assess,
    to_json,
    to_markdown,
    to_text,
    unreadable,
)

SQL = "SELECT order_id, amount * 2 AS doubled FROM orders WHERE status = 'paid'"
CODE = sparkshift.convert(SQL).code


@pytest.fixture
def sql_file(tmp_path: Path) -> Path:
    path = tmp_path / "query.sql"
    path.write_text(SQL, encoding="utf-8")
    return path


def test_convert_prints_the_code(
    sql_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["convert", str(sql_file)]) == EXIT_CONVERTED

    out, err = capsys.readouterr()
    assert out == CODE
    assert err == ""


@pytest.mark.parametrize("dialect", ["tsql", "TSQL", "postgres", "bigquery"])
def test_convert_honors_the_dialect(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], dialect: str
) -> None:
    sql = "SELECT TOP 3 name FROM customers" if "tsql" in dialect.lower() else SQL
    path = tmp_path / "query.sql"
    path.write_text(sql, encoding="utf-8")

    assert main(["convert", str(path), "--dialect", dialect]) == EXIT_CONVERTED

    assert capsys.readouterr().out == sparkshift.convert(sql, dialect=dialect).code


def test_convert_a_sas_program_with_its_warnings(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    program = "data us; set customers(keep=id name); where country = 'US'; run;"
    path = tmp_path / "job.sas"
    path.write_text(program, encoding="utf-8")

    assert main(["convert", str(path), "-d", "sas"]) == EXIT_CONVERTED

    out, err = capsys.readouterr()
    assert out == sparkshift.convert(program, dialect="sas").code
    assert err.startswith(f"sparkshift: warning in {path}: KEEP of several variables")


@pytest.mark.parametrize("arguments", [[], ["-d", "tsql"]])
def test_a_sas_file_is_always_a_sas_program(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], arguments: list[str]
) -> None:
    program = "data big; set orders; where amount > 100; run;"
    path = tmp_path / "JOB.SAS"
    path.write_text(program, encoding="utf-8")

    assert main(["convert", str(path), *arguments]) == EXIT_CONVERTED

    assert capsys.readouterr().out == sparkshift.convert(program, dialect="sas").code


def test_convert_reads_standard_input(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(sys, "stdin", io.StringIO(SQL))

    assert main(["convert", "-"]) == EXIT_CONVERTED

    assert capsys.readouterr().out == CODE


def test_convert_writes_the_output_file(
    sql_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "query.py"

    assert main(["convert", str(sql_file), "-o", str(output)]) == EXIT_CONVERTED

    assert output.read_bytes() == CODE.encode()  # LF line endings everywhere
    assert capsys.readouterr() == ("", "")


def test_convert_writes_a_notebook(
    sql_file: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "query_notebook.py"

    arguments = ["convert", str(sql_file), "--notebook", "-o", str(output)]
    assert main(arguments) == EXIT_CONVERTED

    expected = sparkshift.to_notebook(sparkshift.convert(SQL), source=str(sql_file))
    assert output.read_text(encoding="utf-8") == expected


def test_a_notebook_starts_its_widgets_at_the_given_catalog_and_schema(
    sql_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    arguments = ["convert", str(sql_file), "--notebook"]
    arguments += ["--catalog", "workspace", "--schema", "sparkshift"]
    arguments += ["--output-catalog", "main", "--output-schema", "results"]

    assert main(arguments) == EXIT_CONVERTED

    expected = sparkshift.to_notebook(
        sparkshift.convert(SQL),
        source=str(sql_file),
        catalog="workspace",
        schema="sparkshift",
        output_catalog="main",
        output_schema="results",
    )
    assert capsys.readouterr().out == expected


@pytest.mark.parametrize(
    "option", ["--catalog", "--schema", "--output-catalog", "--output-schema"]
)
def test_catalog_and_schema_need_a_notebook(sql_file: Path, option: str) -> None:
    with pytest.raises(SystemExit) as caught:
        main(["convert", str(sql_file), option, "x"])

    assert caught.value.code == EXIT_USAGE


def test_a_notebook_from_standard_input(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(sys, "stdin", io.StringIO("data a; set t; run;"))

    assert main(["convert", "-", "-d", "sas", "--notebook"]) == EXIT_CONVERTED

    result = sparkshift.convert("data a; set t; run;", dialect="sas")
    assert capsys.readouterr().out == sparkshift.to_notebook(result, dialect="sas")


def test_unsupported_sql_lists_every_issue_on_standard_error(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    path = tmp_path / "bad.sql"
    path.write_text("SELECT my_udf(a) AS x, other_udf(b) AS y FROM t", encoding="utf-8")

    assert main(["convert", str(path)]) == EXIT_NOT_CONVERTED

    out, err = capsys.readouterr()
    assert out == ""
    assert err == (
        f"sparkshift: cannot convert {path}: 2 unsupported constructs:\n"
        "  - function MY_UDF: MY_UDF(a)\n"
        "  - function OTHER_UDF: OTHER_UDF(b)\n"
    )


@pytest.mark.parametrize(
    ("sql", "message"),
    [
        ("SELECT (a FROM t", "line 1, column"),
        ("SELECT 1 FROM t; SELECT 2 FROM t", "statement"),
        ("", "no sql statement"),
    ],
)
def test_invalid_sql_is_not_converted(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    sql: str,
    message: str,
) -> None:
    monkeypatch.setattr(sys, "stdin", io.StringIO(sql))

    assert main(["convert", "-"]) == EXIT_NOT_CONVERTED

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith("sparkshift: cannot convert standard input: ")
    assert message in err.lower()


def test_failed_conversion_writes_no_output_file(tmp_path: Path) -> None:
    path = tmp_path / "bad.sql"
    path.write_text("SELECT my_udf(a) AS x FROM t", encoding="utf-8")
    output = tmp_path / "bad.py"

    assert main(["convert", str(path), "-o", str(output)]) == EXIT_NOT_CONVERTED

    assert not output.exists()


def test_warnings_go_to_standard_error(
    sql_file: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    # No conversion produces warnings yet; the command line must show them.
    warning = Diagnostic("fallback used", "x", "Review it.")
    monkeypatch.setattr(
        "sparkshift.cli.convert",
        lambda sql, dialect: ConversionResult("result = x\n", (warning,)),
    )

    assert main(["convert", str(sql_file)]) == EXIT_CONVERTED

    out, err = capsys.readouterr()
    assert out == "result = x\n"
    assert (
        err
        == f"sparkshift: warning in {sql_file}: fallback used: x. Hint: Review it.\n"
    )


@pytest.mark.parametrize(
    ("arguments", "message"),
    [
        (["convert", "missing.sql"], "cannot read missing.sql"),
        (["convert", "-", "--dialect", "sqlserver"], "invalid choice: 'sqlserver'"),
        ([], "required"),
        (["translate", "q.sql"], "invalid choice: 'translate'"),
    ],
)
def test_usage_errors_exit_with_2(
    capsys: pytest.CaptureFixture[str], arguments: list[str], message: str
) -> None:
    with pytest.raises(SystemExit) as caught:
        main(arguments)

    assert caught.value.code == EXIT_USAGE
    assert message in capsys.readouterr().err


def test_unreadable_and_unwritable_files_are_usage_errors(
    tmp_path: Path, sql_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    latin1 = tmp_path / "latin1.sql"
    latin1.write_bytes("SELECT 'café' AS x FROM t".encode("latin-1"))

    with pytest.raises(SystemExit) as caught:
        main(["convert", str(latin1)])
    assert caught.value.code == EXIT_USAGE
    assert "is not UTF-8 text" in capsys.readouterr().err

    with pytest.raises(SystemExit) as caught:
        main(["convert", str(sql_file), "-o", str(tmp_path)])  # a directory
    assert caught.value.code == EXIT_USAGE
    assert f"cannot write {tmp_path}" in capsys.readouterr().err


def test_version(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as caught:
        main(["--version"])

    assert caught.value.code == 0
    assert capsys.readouterr().out == f"sparkshift {sparkshift.__version__}\n"


def test_python_dash_m_runs_the_command_line(
    sql_file: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setattr(sys, "argv", ["sparkshift", "convert", str(sql_file)])

    with pytest.raises(SystemExit) as caught:
        runpy.run_module("sparkshift", run_name="__main__")

    assert caught.value.code == EXIT_CONVERTED
    assert capsys.readouterr().out == CODE


def test_installed_script(sql_file: Path) -> None:
    # The `sparkshift` command the package installs, run as a real process.
    script = shutil.which("sparkshift", path=str(Path(sys.executable).parent))
    assert script is not None, "the sparkshift script is not installed"

    completed = subprocess.run(
        [script, "convert", str(sql_file)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert completed.returncode == EXIT_CONVERTED
    assert completed.stdout == CODE
    assert completed.stderr == ""


def test_importing_main_does_not_run_the_command_line(
    capsys: pytest.CaptureFixture[str],
) -> None:
    # Tools that import every module, such as the architecture tests, must
    # not start the command line.
    sys.modules.pop("sparkshift.__main__", None)

    importlib.import_module("sparkshift.__main__")

    assert capsys.readouterr() == ("", "")


# --- Converting a directory --------------------------------------------------


@pytest.fixture
def queries(tmp_path: Path) -> Path:
    """A directory of queries: two convertible (one nested), one not, one
    not UTF-8, and a file that is not SQL."""
    root = tmp_path / "queries"
    (root / "reports").mkdir(parents=True)
    (root / "a_orders.sql").write_text(SQL, encoding="utf-8")
    (root / "reports" / "b_customers.sql").write_text(
        "SELECT name FROM customers", encoding="utf-8"
    )
    (root / "c_bad.sql").write_text("SELECT my_udf(a) AS x FROM t", encoding="utf-8")
    (root / "d_latin1.sql").write_bytes("SELECT 'café' AS x FROM t".encode("latin-1"))
    (root / "notes.txt").write_text("not a query", encoding="utf-8")
    return root


def test_directory_converts_each_sql_file_into_the_output_directory(
    queries: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "pyspark"

    assert main(["convert", str(queries), "-o", str(output)]) == EXIT_NOT_CONVERTED

    written = sorted(path.relative_to(output) for path in output.rglob("*"))
    assert written == [
        Path("a_orders.py"),
        Path("reports"),
        Path("reports/b_customers.py"),
    ]
    assert (output / "a_orders.py").read_text(encoding="utf-8") == CODE
    assert (output / "reports" / "b_customers.py").read_text(
        encoding="utf-8"
    ) == sparkshift.convert("SELECT name FROM customers").code

    out, err = capsys.readouterr()
    assert out == ""
    assert err == (
        f"sparkshift: cannot convert {queries / 'c_bad.sql'}: "
        "1 unsupported construct:\n"
        "  - function MY_UDF: MY_UDF(a)\n"
        f"sparkshift: cannot read {queries / 'd_latin1.sql'}: it is not UTF-8 text\n"
        "sparkshift: converted 2 of 4 files; 2 could not be converted\n"
    )


def test_directory_where_everything_converts_exits_with_0(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "queries"
    source.mkdir()
    (source / "only.sql").write_text(SQL, encoding="utf-8")

    assert main(["convert", str(source), "-o", str(tmp_path / "out")]) == EXIT_CONVERTED

    assert capsys.readouterr().err == "sparkshift: converted 1 of 1 file\n"


def test_directory_applies_the_dialect_to_every_file(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "queries"
    source.mkdir()
    (source / "top.sql").write_text(
        "SELECT TOP 2 name FROM customers", encoding="utf-8"
    )
    output = tmp_path / "out"

    assert main(["convert", str(source), "-o", str(output), "-d", "tsql"]) == 0

    assert (output / "top.py").read_text(encoding="utf-8") == sparkshift.convert(
        "SELECT TOP 2 name FROM customers", dialect="tsql"
    ).code


def test_unreadable_file_in_a_directory_is_counted_as_not_converted(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "queries"
    source.mkdir()
    locked = source / "locked.sql"
    locked.write_text(SQL, encoding="utf-8")
    locked.chmod(0)
    try:
        if os.access(locked, os.R_OK):
            pytest.skip("this user can read files without read permission")
        exit_code = main(["convert", str(source), "-o", str(tmp_path / "out")])
    finally:
        locked.chmod(0o644)

    assert exit_code == EXIT_NOT_CONVERTED
    assert f"cannot read {locked}: Permission denied" in capsys.readouterr().err


def usage_error(arguments: list[str], capsys: pytest.CaptureFixture[str]) -> str:
    """Run the command line, check it exits with a usage error, and return
    what it printed on standard error."""
    with pytest.raises(SystemExit) as caught:
        main(arguments)
    assert caught.value.code == EXIT_USAGE
    return capsys.readouterr().err


def test_directory_needs_an_output_directory(
    queries: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    err = usage_error(["convert", str(queries)], capsys)

    assert "needs --output DIRECTORY" in err


def test_directory_output_cannot_be_a_file(
    queries: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "out.py"
    output.write_text("", encoding="utf-8")

    err = usage_error(["convert", str(queries), "-o", str(output)], capsys)

    assert f"--output {output} must be a directory, not a file" in err


def test_directory_without_sql_files(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    empty = tmp_path / "empty"
    empty.mkdir()

    err = usage_error(["convert", str(empty), "-o", str(tmp_path / "out")], capsys)

    assert f"no .sql or .sas files in {empty}" in err


SAS = "data big; set orders; where amount > 100; run;"


@pytest.fixture
def mixed(tmp_path: Path) -> Path:
    """A directory of SQL queries and SAS programs."""
    root = tmp_path / "jobs"
    root.mkdir()
    (root / "a_query.sql").write_text(
        "SELECT TOP 2 name FROM customers", encoding="utf-8"
    )
    (root / "b_job.sas").write_text(SAS, encoding="utf-8")
    return root


def test_directory_converts_sql_and_sas_files(
    mixed: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "out"

    assert main(["convert", str(mixed), "-o", str(output), "-d", "tsql"]) == 0

    assert (output / "a_query.py").read_text(encoding="utf-8") == sparkshift.convert(
        "SELECT TOP 2 name FROM customers", dialect="tsql"
    ).code
    assert (output / "b_job.py").read_text(encoding="utf-8") == sparkshift.convert(
        SAS, dialect="sas"
    ).code
    assert capsys.readouterr().err == "sparkshift: converted 2 of 2 files\n"


def test_directory_of_notebooks(
    mixed: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "notebooks"

    arguments = ["convert", str(mixed), "-o", str(output), "-d", "tsql", "--notebook"]
    assert main(arguments) == 0

    sql = sparkshift.convert("SELECT TOP 2 name FROM customers", dialect="tsql")
    assert (output / "a_query.py").read_text(encoding="utf-8") == (
        sparkshift.to_notebook(sql, source="a_query.sql", dialect="tsql")
    )
    sas = sparkshift.convert(SAS, dialect="sas")
    assert (output / "b_job.py").read_text(encoding="utf-8") == (
        sparkshift.to_notebook(sas, source="b_job.sas", dialect="sas")
    )


def test_dialect_sas_selects_the_sas_programs(
    mixed: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "out"

    assert main(["convert", str(mixed), "-o", str(output), "-d", "sas"]) == 0

    assert sorted(path.name for path in output.iterdir()) == ["b_job.py"]


def test_directory_without_sas_files(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "queries"
    source.mkdir()
    (source / "only.sql").write_text(SQL, encoding="utf-8")

    arguments = ["convert", str(source), "-o", str(tmp_path / "out"), "-d", "sas"]
    err = usage_error(arguments, capsys)

    assert f"no .sas files in {source}" in err


@pytest.mark.parametrize(
    ("dialect", "language", "files"),
    [
        (None, "generic SQL; SAS for .sas files", 2),
        ("tsql", "tsql; SAS for .sas files", 2),
        ("sas", "SAS", 1),
    ],
)
def test_report_names_the_languages(
    mixed: Path,
    capsys: pytest.CaptureFixture[str],
    dialect: str | None,
    language: str,
    files: int,
) -> None:
    arguments = ["report", str(mixed)] + (["-d", dialect] if dialect else [])

    assert main(arguments) == EXIT_CONVERTED

    out = capsys.readouterr().out
    assert out.startswith(f"SparkShift coverage report: {mixed} ({language})\n")
    assert re.search(rf"^Files +{files}$", out, re.MULTILINE)


def test_unwritable_output_directory_is_a_usage_error(
    queries: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "out"
    output.mkdir()
    (output / "a_orders.py").mkdir()  # a directory where a file must go

    err = usage_error(["convert", str(queries), "-o", str(output)], capsys)

    assert f"cannot write {output / 'a_orders.py'}" in err


# --- Coverage reports ----------------------------------------------------------


def _report_of(queries: Path, dialect: str | None = None) -> Report:
    """The report the command should produce for the queries fixture."""
    return Report(
        str(queries),
        dialect,
        (
            assess("a_orders.sql", SQL, dialect),
            assess("c_bad.sql", "SELECT my_udf(a) AS x FROM t", dialect),
            unreadable("d_latin1.sql", "it is not UTF-8 text"),
            assess("reports/b_customers.sql", "SELECT name FROM customers", dialect),
        ),
    )


@pytest.mark.parametrize(
    ("arguments", "render"),
    [([], to_text), (["--format", "markdown"], to_markdown), (["-f", "json"], to_json)],
)
def test_report_on_a_directory(
    queries: Path,
    capsys: pytest.CaptureFixture[str],
    arguments: list[str],
    render: Callable[[Report], str],
) -> None:
    assert main(["report", str(queries), *arguments]) == EXIT_CONVERTED

    out, err = capsys.readouterr()
    assert out == render(_report_of(queries))
    assert err == ""


def test_report_on_one_file_with_a_dialect(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    path = tmp_path / "top.sql"
    path.write_text("SELECT TOP 2 name FROM customers", encoding="utf-8")

    assert main(["report", str(path), "-d", "tsql", "-f", "json"]) == EXIT_CONVERTED

    data = json.loads(capsys.readouterr().out)
    assert data["dialect"] == "tsql"
    assert data["files"] == [
        {"path": str(path), "status": "converted", "findings": [], "error": None}
    ]


def test_report_writes_the_output_file(
    queries: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    output = tmp_path / "reports" / "coverage.md"

    assert main(["report", str(queries), "-f", "markdown", "-o", str(output)]) == 0

    assert output.read_text(encoding="utf-8") == to_markdown(_report_of(queries))
    assert capsys.readouterr().out == ""


@pytest.mark.parametrize(
    ("threshold", "exit_code"),
    [("0", 0), ("50", 0), ("50.1", 1), ("100", 1)],
)
def test_report_fail_under(
    queries: Path, capsys: pytest.CaptureFixture[str], threshold: str, exit_code: int
) -> None:
    # Two of the four files convert: exactly 50%.
    assert main(["report", str(queries), "--fail-under", threshold]) == exit_code

    err = capsys.readouterr().err
    if exit_code:
        assert err == (
            f"sparkshift: converted 2 of 4 files (50.0%), "
            f"below --fail-under {float(threshold):g}%\n"
        )
    else:
        assert err == ""


def test_fail_under_compares_exact_shares(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "queries"
    source.mkdir()
    for name, sql in [("a", SQL), ("b", SQL), ("c", "SELECT my_udf(a) AS x FROM t")]:
        (source / f"{name}.sql").write_text(sql, encoding="utf-8")

    # 2 of 3 is 66.666...%: shown rounded as 66.7%, yet below 66.67.
    arguments = ["report", str(source), "--fail-under", "66.67"]
    assert main(arguments) == EXIT_NOT_CONVERTED
    assert "(66.7%), below --fail-under 66.67%" in capsys.readouterr().err
    assert main([*arguments[:-1], "66.66"]) == EXIT_CONVERTED


@pytest.mark.parametrize("threshold", ["-1", "100.5", "lots"])
def test_report_rejects_bad_thresholds(
    queries: Path, capsys: pytest.CaptureFixture[str], threshold: str
) -> None:
    usage_error(["report", str(queries), "--fail-under", threshold], capsys)


def test_report_usage_errors(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    missing = tmp_path / "missing"
    empty = tmp_path / "empty"
    empty.mkdir()

    err = usage_error(["report", str(missing)], capsys)
    assert f"cannot read {missing}: no such file or directory" in err

    err = usage_error(["report", str(empty)], capsys)
    assert f"no .sql or .sas files in {empty}" in err

    err = usage_error(["report", str(empty), "-f", "html"], capsys)
    assert "invalid choice: 'html'" in err


# --- Pipeline source files -----------------------------------------------------------


def test_convert_writes_a_pipeline_source_file(
    sql_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    arguments = ["convert", str(sql_file), "--pipeline", "--schema", "raw"]

    assert main(arguments) == EXIT_CONVERTED

    expected = sparkshift.to_pipeline(
        sparkshift.convert(SQL), source=str(sql_file), schema="raw"
    )
    assert capsys.readouterr() == (expected, "")


@pytest.mark.parametrize(
    ("options", "message"),
    [
        (["--pipeline", "--notebook"], "not allowed with argument"),
        (["--pipeline", "--output-schema", "x"], "are for notebooks"),
        (["--pipeline", "--output-catalog", "x"], "are for notebooks"),
        (["--pipeline", "--catalog", "main"], "--catalog needs --schema"),
    ],
)
def test_pipeline_options(
    sql_file: Path,
    capsys: pytest.CaptureFixture[str],
    options: list[str],
    message: str,
) -> None:
    with pytest.raises(SystemExit) as caught:
        main(["convert", str(sql_file), *options])

    assert caught.value.code == EXIT_USAGE
    assert message in capsys.readouterr().err


def test_a_program_that_cannot_be_a_pipeline_is_reported(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    path = tmp_path / "report.sas"
    path.write_text("proc print data=t; run;", encoding="utf-8")

    assert main(["convert", str(path), "--pipeline"]) == EXIT_NOT_CONVERTED

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith(
        f"sparkshift: cannot convert {path}: 1 unsupported construct:\n"
        "  - a pipeline of a program that creates no data set"
    )


def test_a_directory_of_pipeline_files_defines_each_dataset_once(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "jobs"
    (source / "a").mkdir(parents=True)
    (source / "b").mkdir()
    (source / "a" / "daily.sql").write_text("SELECT x FROM t", encoding="utf-8")
    (source / "b" / "daily.sql").write_text("SELECT y FROM u", encoding="utf-8")
    (source / "load.sas").write_text("data clean; set raw; run;", encoding="utf-8")
    (source / "show.sas").write_text("proc print data=clean; run;", encoding="utf-8")
    output = tmp_path / "out"

    arguments = ["convert", str(source), "--pipeline", "-o", str(output)]
    assert main(arguments) == EXIT_NOT_CONVERTED

    err = capsys.readouterr().err
    written = sorted(path.relative_to(output).as_posix() for path in output.rglob("*"))
    assert written == ["load.py"]
    first, second = source / "a" / "daily.sql", source / "b" / "daily.sql"
    assert (
        f"cannot convert {first}: its dataset daily is also defined by {second}; "
        "a pipeline defines each dataset once"
    ) in err
    assert (
        f"cannot convert {second}: its dataset daily is also defined by {first}" in err
    )
    assert err.endswith("converted 1 of 4 files; 3 could not be converted\n")
    load = sparkshift.convert("data clean; set raw; run;", dialect="sas")
    assert (output / "load.py").read_text(encoding="utf-8") == sparkshift.to_pipeline(
        load, source="load.sas", dialect="sas"
    )
