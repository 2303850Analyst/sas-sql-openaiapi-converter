# Testing and correctness

SparkShift's central claim is that generated code returns the same result as
the original SQL. That claim is checked by executing both on real Apache Spark.

## Test layers

| Layer | Location | What it checks | Needs Spark |
|---|---|---|---|
| Unit | `tests/test_*.py` | Parsing, translation decisions, error messages | No |
| Golden output | `tests/test_emit.py`, `tests/test_api.py` | The exact generated code, so readability changes are deliberate | No |
| Formatting | `tests/equivalence/test_formatting.py` | Every scenario's generated code, and that of sample queries written the way people paste them, fits 88 columns, and wrapping at any width leaves the Python syntax tree unchanged | No |
| Browser | `tests/playground/` | The playground, in headless Chromium, converts every example exactly as the command line does | No (needs Chromium and network) |
| Architecture | `tests/test_architecture.py` | Dependency rules: no PySpark in the core, SQLGlot only in the frontend | No |
| Equivalence | `tests/equivalence/` | Original SQL and generated PySpark return equivalent results | Yes |
| SAS scenarios | `tests/equivalence/test_sas.py` | SAS programs' generated PySpark returns rows written by hand from SAS's documented rules (no SAS is available; see [sas.md](sas.md)) | Yes |
| Real databases | `tests/equivalence/test_postgres.py`, `test_mysql.py` | PostgreSQL and MySQL queries, run on real servers, return what the generated PySpark returns | Yes (and a database server) |

Run everything with `uv run pytest`, or skip Spark with `uv run pytest -m "not spark"`.
Database tests skip unless a server is configured (see below). CI runs the
unit and Spark tests in four processes (`-n 4 --dist loadscope`, see
[CONTRIBUTING.md](../CONTRIBUTING.md#running-checks)): the same tests as in
one process, measured at 3218 passed and 26 skipped either way, in 78–82
seconds instead of 137 on a development machine.

## Equivalence testing

```mermaid
flowchart LR
    SQL[SQL] --> Ref["spark.sql(sql)"]
    SQL --> Convert[sparkshift.convert] --> Exec[execute generated code]
    Ref --> Compare{compare}
    Exec --> Compare
```

For each scenario, `assert_equivalent(spark, sql)`:

1. Runs `spark.sql(sql)` to produce the reference result.
2. Converts the SQL with SparkShift and executes the generated code, which must
   assign a DataFrame to `result`.
3. Compares the two results using the rules below.

The SQL must also be valid Spark SQL, because it is executed directly as the
reference.

## Comparison rules

Comparing `collect()` output with `==` would be wrong for SQL. The comparator
in `tests/equivalence/compare.py` applies these rules:

| # | Rule | Why |
|---|---|---|
| 1 | **Row order is ignored, unless the query has `ORDER BY`** | Without `ORDER BY`, SQL guarantees no row order. Two correct plans may return rows in different orders. |
| 2 | **Rows are compared as a multiset** | Duplicate rows must match in number. Comparing as a set would hide a bug that removes duplicates. |
| 3 | **Column names, order, and types must match** | `SELECT *` must produce the same columns in the same order; `int` vs `bigint` or a different decimal scale is a real difference to consumers. |
| 4 | **Nullability flags are ignored** | Spark derives "may contain NULL" metadata differently depending on the code path. Actual NULL values are still compared. |
| 5 | **NULL matches NULL** | In SQL, `NULL = NULL` is not true, but when comparing results, NULL in both means they agree. |
| 6 | **Floats match within a tolerance; everything else exactly** | Floating-point addition is not associative, so a different evaluation order can change the last digits. Decimals, strings, dates, and timestamps must match exactly. |
| 7 | **`LIMIT` without `ORDER BY`: count plus sub-multiset** | Such a query may return *any* `n` rows, so two correct runs can return different rows. The harness removes the `LIMIT` to build the unlimited reference, then checks that the row count matches and that every returned row exists in the unlimited result, duplicates included. |
| 8 | **`ORDER BY`: tie groups in sequence** | Rows that are equal on the sort keys may come in any order, so comparing lists with `==` would be flaky. Consecutive rows with equal keys form a group; the groups must appear in the same sequence, and each is compared as a multiset. With a `LIMIT`, only the last group may be cut short, and its rows must come from the same group of the unlimited result. |

### Ordered scenarios

A scenario for a query with `ORDER BY` names its `order_keys`: the output
columns whose values decide the order. The harness requires them exactly when
the query has `ORDER BY`, so no ordered query is checked as if order did not
matter. When a query sorts by a column it does not output, the test data has
no ties on that column, and every output column is a key.

### Dialect scenarios

The reference result comes from running the SQL with `spark.sql`, so it must be
valid Spark SQL. For dialect syntax Spark cannot run, such as T-SQL `TOP` or
Oracle `FETCH FIRST`, a scenario supplies a hand-written Spark SQL reference
(`reference_sql`) that expresses the same query.

A hand-written reference is only as right as its author's reading of the
dialect. Where a real database is available, the scenarios also run there.

### Real databases

| Dialect | Checked on the real database | How |
|---|---|---|
| PostgreSQL | Yes: every PostgreSQL dialect scenario and example | A PostgreSQL 18 container in CI |
| MySQL | Yes: every MySQL dialect scenario and example | A MySQL 8.4 container in CI |
| T-SQL, Oracle | Not yet: their free images are heavy | Spark SQL references only |
| Snowflake, BigQuery | No: cloud services that need an account | Spark SQL references only |

`tests/equivalence/test_postgres.py` and `test_mysql.py` load the test tables
into the database (`tests/equivalence/databases.py` describes each engine and
maps each Spark type to one of its types), run each query there exactly as
written, and compare the rows with the generated PySpark's on Spark, using the
rules above with four changes, since engines name and type results their own
way:

- Column names are compared ignoring case (PostgreSQL folds unquoted names to
  lower case), and column types are not compared; values are.
- In a column where either side has a float, numbers are compared as floats;
  otherwise, where either side has a decimal, as decimals.
- In a column where either side has a boolean, 0 and 1 are compared as false
  and true: MySQL returns a comparison such as `amount > 50` as an integer.
- A timestamp with a time zone is compared as the UTC wall-clock time, as Spark
  returns it in a UTC session. A date never matches a timestamp, even at
  midnight.

The MySQL test database compares strings exactly, by code point
(`utf8mb4_0900_bin`), as Spark does. MySQL's default collation ignores case,
accents, and trailing spaces; SparkShift does not emulate that (see the
[known limitations](supported-sql.md#known-limitations)), so the tests check what SparkShift claims to
convert exactly.

Preparing these tests caught a wrong reference: PostgreSQL's documentation
says `date + INTERVAL` returns a timestamp, where Spark and the other dialects
keep a date, and a scenario assumed a date. SparkShift now converts it only
when the value's type is visible in the query, and the scenario checks both
forms on PostgreSQL itself.

To run these tests, point `SPARKSHIFT_POSTGRES_URL` or `SPARKSHIFT_MYSQL_URL`
at a server they may write to (they create and drop the schema or database
`sparkshift_tests`), for example
`postgresql://postgres@localhost:5432/postgres` or
`mysql://root@127.0.0.1:3306`, and run `uv run pytest -m database`. Without a
URL a database's tests skip, except where `SPARKSHIFT_DATABASE_REQUIRED` names
that database (`postgres` or `mysql`), as in its CI job, where they fail
instead, so a green job always means they ran.

### Spark Connect

Databricks serverless compute, including the Free Edition, runs PySpark code
as a Spark Connect client: the DataFrame calls are sent to a remote Spark
server instead of a JVM in the same process. The client builds some
expressions itself, so generated code can behave differently there than in
classic PySpark. The "Spark Connect" CI job runs every Spark test again
through a local Spark Connect server:

```bash
uv sync --group connect
SPARKSHIFT_SPARK_MODE=connect uv run pytest -m spark
```

(A plain `uv sync` removes the `connect` group again.)

It found one difference. The Connect client sends a Python `Decimal` literal
with a precision of at least 10, so `F.lit(Decimal("0.5"))` is
`decimal(10,1)` there but `decimal(1,1)` in classic PySpark and in Spark SQL.
The values are equal, but the wider type changes the types of arithmetic on
it, and near the 38-digit limit, the result itself: a `decimal(30,10)` value
times `F.lit(Decimal("1.11"))` is `decimal(38,9)` through Spark Connect, rounded
to `…358.037037036`, where Spark SQL gives `decimal(34,12)`,
`…358.037037035901`. SparkShift therefore emits a decimal literal as its text cast to its exact
type, `F.lit("0.5").cast("decimal(1,1)")`, the same in both modes.

### Pipelines

`tests/equivalence/test_pipeline_runs.py` runs pipeline source files as
pipelines, on Apache Spark's Spark Declarative Pipelines through the same
local Spark Connect server (so it runs with `SPARKSHIFT_SPARK_MODE=connect`,
in the "Spark Connect" CI job): every SQL example as one pipeline, every SAS
example as another, a file that reads another file's dataset, and a data set
created twice. Each materialized view must hold what the plain code computes
for it. Each pipeline runs in a new schema, because Apache Spark 4.2 can lose
the order of datasets once their tables exist
([ADR 0013](adr/0013-pipelines-from-the-same-plan.md)); for the same reason,
these programs avoid `drop`, `distinct`, and `dropDuplicates` on a dataset of
the pipeline, which `tools/validate_databricks.py --pipeline` runs on
Databricks instead.

### Testing the comparator

A comparator that always reports "equal" would make every equivalence test
pass and prove nothing. `tests/equivalence/test_compare.py` therefore includes
cases that must fail: a missing duplicate, NULL vs empty string, NULL vs zero,
`int` vs `bigint`, reordered columns, unequal decimals, floats outside the
tolerance, and — for `LIMIT` — a wrong row count, a row not in the unlimited
result, and a duplicate returned more often than it exists. For `ORDER BY`,
it must catch reversed order, NULLs at the wrong end, a row moved across a
group boundary, and a cut group padded with a row from elsewhere.

## Test data

`tests/equivalence/datasets.py` defines the `customers` and `orders` tables
with explicit schemas. Rows are chosen to exercise SQL semantics: exact
duplicate rows, NULLs in every nullable column, empty strings, zero and
negative amounts, non-ASCII text, a leap-day timestamp with microseconds,
orders with no or unknown customers, and a customer with no orders.

`tests/equivalence/test_datasets.py` fails if any of these edge cases is
removed, because weakening the data silently weakens every test that uses it.


## Browser worker recovery

The playground's worker tests exercise real CPU-bound Python: an injected bridge
loops indefinitely on one specific input. The page must still run a JavaScript
timer, clear previous output, allow cancellation or input editing, terminate the
blocked worker, reload Python and successfully convert new input. Other tests
inject an unmatched request ID and a runtime crash, check retry after a CDN
failure, and verify that successful requests clear their deadlines.

Conversion deadline tests use Playwright's virtual page clock to advance the
10-second timer; the Python worker still executes on its own thread. A startup
test injects a shorter timer and a worker that never replies. These fixtures do
not add production test hooks or relax production deadlines. Existing tests now
wait for asynchronous conversions to settle before comparing exact output.
