# Python API

Everything below is importable from the `sparkshift` package. SparkShift has
one runtime dependency, SQLGlot, and never needs PySpark or a Spark session to
convert: it returns code as text.

## `convert(sql, dialect=None)`

Converts one SQL query, or a SAS program, into PySpark DataFrame code and
returns a `ConversionResult`.

- `sql`: the query or program text.
- `dialect`: `"tsql"`, `"postgres"`, `"mysql"`, `"snowflake"`, `"bigquery"`,
  `"oracle"`, or `"sas"`, case-insensitive; `None` (the default) for generic
  SQL. With `"sas"`, each data set the program creates becomes a DataFrame
  variable, and `result` is the last one.

```python
import sparkshift

result = sparkshift.convert("SELECT TOP 3 name FROM customers", dialect="tsql")
print(result.code)
for warning in result.warnings:
    print(warning)
```

The generated code imports what it uses, expects a SparkSession named `spark`
(as in a Databricks notebook), and assigns the final DataFrame to `result`.

## `ConversionResult`

The outcome of a successful conversion, an immutable dataclass:

| Field | Type | Meaning |
|---|---|---|
| `code` | `str` | The generated PySpark code |
| `warnings` | `tuple[Diagnostic, ...]` | Things to review before running the code, such as a SAS rule the code follows only partly; empty when there are none |
| `datasets` | `tuple[DataSet, ...]` | The data sets a SAS program creates, in order; empty for SQL |

## `DataSet`

A data set a SAS program creates, an immutable dataclass:

| Field | Type | Meaning |
|---|---|---|
| `name` | `str` | Its name in the program, in lowercase |
| `variable` | `str` | The variable that holds it in the generated code, usually the same name; another one when the name is taken, such as `result_df` for a data set named `result` |

## `Diagnostic`

One finding about one construct, used for warnings and for the issues of
`UnsupportedSQLError`:

| Field | Type | Meaning |
|---|---|---|
| `message` | `str` | What the construct is, such as `function MY_UDF` |
| `sql` | `str` | The fragment of the input it is about |
| `hint` | `str \| None` | A suggested rewrite, when there is one |

`str(diagnostic)` gives `message: sql. Hint: hint`, with long fragments
shortened.

## `to_notebook(result, *, source=None, dialect=None, catalog="", schema="", output_catalog="", output_schema="")`

Returns `result.code` as a Databricks notebook in source format (see
[databricks.md](databricks.md)). `source` names the file the code came from,
for the title and the name of a query's table; `dialect` is the language it
was converted from, as given to `convert`; `catalog` and `schema` are the
initial values of the notebook's `catalog` and `schema` widgets (empty keeps
the current ones); `output_catalog` and `output_schema` are those of the
widgets that choose where results are written (nothing is written while
`output_schema` is empty; see
[writing results](databricks.md#writing-results-to-tables)).

## `to_pipeline(result, *, source=None, dialect=None, catalog="", schema="")`

Returns the datasets of `result` as a pipeline source file for Lakeflow
pipelines (see [pipelines.md](pipelines.md)): each data set a SAS program
creates, or a query's result, is a materialized view. `source` names the
file the code came from, which names a query's dataset; `dialect` is the
language it was converted from, as given to `convert`; `schema` (in
`catalog`, if given) is where tables without a schema are read from. It
raises `UnsupportedSQLError` for a program a pipeline cannot run, and
`ValueError` for a `catalog` without a `schema`, or a `result` that does not
come from `convert`.

## Errors

Every error derives from `SparkShiftError`, so one `except` handles them all:

| Exception | Raised when | Attributes |
|---|---|---|
| `UnsupportedDialectError` | `dialect` is not supported | `dialect`, `supported` |
| `SQLParseError` | The input is empty or is not valid SQL | `message`, `line`, `column` (1-based; `None` when unknown) |
| `SASParseError` | The input is empty or is not a valid SAS program; a subclass of `SQLParseError` | as `SQLParseError` |
| `MultipleStatementsError` | The SQL contains more than one statement | `count` |
| `UnsupportedSQLError` | The input is valid but uses constructs SparkShift cannot translate safely | `issues`: every unsupported construct, as `Diagnostic`s |

```python
try:
    sparkshift.convert(sql, dialect="snowflake")
except sparkshift.UnsupportedSQLError as error:
    for issue in error.issues:
        print(issue.message, issue.hint)
```

## Version

`sparkshift.__version__` is the installed version.
