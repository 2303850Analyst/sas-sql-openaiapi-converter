# Roadmap

SparkShift's first release, 0.1.0, is on
[PyPI](https://pypi.org/project/sparkshift/). This roadmap describes intended
scope, not current capabilities; see the README and
[docs/supported-sql.md](docs/supported-sql.md) for what works today.
Phases are listed in the order they are planned; their numbers are kept
from the original plan.

Status legend: **Done** · **In progress** · **Planned**

| Phase | Scope | Status |
|---|---|---|
| 0 | Engineering foundation: packaging, tooling, CI, architecture notes | Done |
| 1 | Core SQL → PySpark engine: expressions, SELECT/WHERE, joins, aggregation, ordering, window functions, CTEs, set operations, subqueries — with Spark equivalence tests | Done |
| 2 | CLI (`sparkshift convert`), packaging polish, verified examples | Done |
| 6 | Public browser-based playground (live demo) | Done |
| 3 | Advanced SQL: QUALIFY, multi-dialect testing, coverage reporting | Done |
| 4 | SAS → PySpark for a documented subset (DATA step, PROC SQL/SORT/MEANS/FREQ) | Done |
| 5 | Databricks notebooks, Spark Connect testing, upload to a workspace, and validation on Databricks | Done |
| 7 | Documentation polish and the first release on PyPI (0.1.0) | Done |
| 8 | Playground 2.0: a redesigned playground, converting whole folders in the browser, notebooks that write their results to tables and show as cells, and deploying them to Databricks as a job; everyday SAS (data lines, `PROC PRINT`, `FORMAT`, date parts, `PROPCASE`, and `CASE` and `CALCULATED` in `PROC SQL`) | Done |
| 9 | Lakeflow pipelines (formerly Delta Live Tables) as a conversion and deployment target, alongside jobs: pipeline source files, creating the pipeline from the CLI and the playground | In progress |

## Guiding principle

A smaller set of constructs that are verified correct is preferred over a large
set that is not. Constructs SparkShift cannot translate safely are rejected with
a clear error instead of producing code that might be wrong.
