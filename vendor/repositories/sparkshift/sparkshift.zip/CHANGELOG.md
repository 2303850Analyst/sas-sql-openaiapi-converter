# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed

- The playground shows a notebook as its cells, as Databricks does: the
  Markdown formatted, each code cell on its own, and the setup cells (widgets,
  and writing results to tables) folded until opened. Copy and Download still
  give the notebook file.
- The playground has a new design: side-by-side editors with line numbers and
  syntax highlighting, a dark and a light theme (remembered per browser), and
  self-hosted fonts.
- The playground starts empty and converts only when you press Convert:
  examples ("Try an example") and shared links fill the editor and wait.
  **Open file** reads a `.sql` or `.sas` file into the editor, and a hint
  offers to switch the source language when a SAS program is pasted under a
  SQL dialect, or SQL under SAS.

### Added

- Lakeflow pipelines: `convert --pipeline` writes pipeline source files,
  where each data set a SAS program creates, or a query's result, is a
  materialized view (`sparkshift.to_pipeline`), and `upload --pipeline`
  uploads them and creates the pipeline on serverless compute. Datasets read
  each other by name, so the pipeline orders them; a data set created twice
  is first a temporary view. See docs/pipelines.md and ADR 0013.
- The playground shows a program as a pipeline source file (**Pipeline**),
  converts folders into them, and deploys them: the Deploy tab can create a
  Lakeflow pipeline instead of a job, with a **Create pipeline** notebook
  that creates or updates it in the workspace.
- The playground can show the Databricks notebook that `convert --notebook`
  writes, and download the result as a `.py` file.
- The playground converts folders: drop or choose a folder or files, see each
  file's result, and download a zip with exactly what `sparkshift convert
  FOLDER -o OUT` would write. The command line and the playground share the
  batch rules (`sparkshift.batch`).
- Notebooks can write their results to tables: `output_catalog` and
  `output_schema` widgets (`--output-catalog`, `--output-schema` on
  `convert --notebook` and `upload`) choose where; a SAS program writes each
  data set it creates, a SQL query its result, named after its file, and
  existing tables are replaced. Nothing is written while `output_schema` is
  empty.
- `ConversionResult.datasets` lists the data sets a SAS program creates, as
  `DataSet(name, variable)`.
- SAS: `PROC PRINT` (with `VAR`, `WHERE`, and its printout options), whose
  data set becomes the result; the `FORMAT` statement, which changes no
  value; `YEAR`, `MONTH`, `DAY`, `QTR`, and `WEEKDAY`; and `PROPCASE`, exact
  for its default delimiters (blank, `/`, `-`, `(`, `.`, tab). Data lines after
  `DATALINES` (or `CARDS`) are read as data, so they no longer appear as
  statements in the list of unsupported constructs.
- SAS: a DATA step that reads data lines with `INPUT` (list input, with `$`
  and the `$w.`, `w.d`, `BESTw.`, `DATEw.`, `YYMMDDw.`, `MMDDYYw.`, and
  `DDMMYYw.` informats) becomes `spark.createDataFrame(...)` with its rows
  written in the code, read by SAS's rules: missing values, text lengths
  (from `LENGTH`, the informat, or 8), implied decimals, `FLOWOVER`, and
  `LOST CARD`, with a warning for each note SAS would write. Later steps know
  the columns of such a data set, their types, and their text lengths.
- Two SAS examples bring their own data as data lines:
  `customer_cleanup.sas` (cleaning, `PROC SORT`, `PROC PRINT`) and
  `account_risk.sas` (`PROC SQL` with `CASE` and `CALCULATED`). They are in
  the playground's examples too.
- SAS PROC SQL: `CASE` expressions (with conditions, or an operand compared
  with each value; missing without `ELSE`), also inside summary functions, and
  `CALCULATED` columns in `SELECT` and `WHERE`; in a query with summaries, a
  column computed from summarized columns is added after them. Joins on
  columns of tables read from data lines are compared by SAS's rules without
  the "equality of two columns" warning.
- `sparkshift upload --job [NAME]` also creates a Databricks job that runs the
  uploaded notebooks in order on serverless compute, with the notebooks'
  widgets as its parameters; `--overwrite` updates a job of the same name. It
  is created only if every file converts and uploads. `sparkshift.jobs` also
  writes a notebook that creates the same job when run in a workspace.
- The playground's **Deploy** tab imports a converted folder's notebooks and
  that Create job notebook into a Databricks workspace, with a personal
  access token kept only in the page's memory and sent only to the
  workspace. The page may connect to Databricks workspaces and no other site.

### Fixed

- A SAS data set named `display` or `dbutils` no longer gets a variable of
  that name, which hid the functions a Databricks notebook calls after the
  code; it is named `display_df` or `dbutils_df`.

## [0.1.0] - 2026-10-15

The first public release. SparkShift converts SQL `SELECT` queries, from
generic SQL and six dialects (T-SQL, PostgreSQL, MySQL, Snowflake, BigQuery,
and Oracle), and a documented subset of SAS (DATA steps and `PROC SORT`,
`MEANS`, `SUMMARY`, `FREQ`, and `SQL`) into readable PySpark DataFrame code,
and rejects what it cannot translate exactly with an explanation. It comes
with a command line (`convert`, `report`, `upload`), Databricks notebooks and
upload (`pip install "sparkshift[databricks]"`), and an
[in-browser playground](https://arttgrantollii.github.io/sparkshift/).
Supported constructs are tested by running the original and the generated
code on Apache Spark, including through Spark Connect; PostgreSQL and MySQL
queries also on real servers; and the examples on Databricks.

### Added

- `convert --strict` rejects warned conversions with exit status 1 before writing
  their output, including notebooks and batch conversions. Warning-free batch
  inputs still convert; existing outputs of rejected inputs stay untouched.

- Project skeleton: `src/` layout, `pyproject.toml` packaging, Apache-2.0 license.
- Test and quality tooling: pytest, coverage, Ruff, and pre-commit hooks.
- Architecture test ensuring the core package never imports PySpark.
- Spark smoke test verifying a local SparkSession can execute SQL.
- GitHub Actions CI: lint, and tests on Python 3.11 and 3.14 with Java 21.
- Architecture note and first ADRs (SQLGlot for parsing; PySpark not a runtime dependency).
- SQL parsing for the generic dialect plus T-SQL, PostgreSQL, MySQL, Snowflake,
  BigQuery, and Oracle, with SparkShift error types (`SQLParseError`,
  `UnsupportedDialectError`, `MultipleStatementsError`) that report readable
  messages with line and column.
- `sparkshift.convert()`: the first public API. Converts `SELECT * FROM table`
  into PySpark and returns a `ConversionResult`; all other queries raise
  `UnsupportedSQLError` listing every unsupported construct.
- Intermediate representation and emitter (ADR 0003), with architecture tests
  keeping SQLGlot out of both.
- Spark equivalence testing: executes the original SQL and the generated
  PySpark on the same datasets and compares results with SQL semantics
  (unordered multiset rows, exact schema, NULL-aware, float tolerance).
  Test datasets cover duplicates, NULLs, empty strings, and other edge cases.
- Expressions in the SELECT list: columns, qualified columns, `*`, aliases,
  literals (integer, exact decimal, double, string, boolean, NULL), arithmetic,
  comparisons, and `AND`/`OR`/`NOT`. Generated code imports what it uses and
  adds parentheses according to Python's operator precedence.
- Operators whose meaning differs from Spark in the source dialect (integer
  division in T-SQL/PostgreSQL, NULL-on-zero division in MySQL, `+` in T-SQL)
  are rejected with an explanation.
- `WHERE`, `DISTINCT`, and row limits (`LIMIT n`, T-SQL `TOP n`,
  `FETCH FIRST n ROWS ONLY`), emitted in SQL's logical evaluation order.
  `DISTINCT ON`, `PERCENT`, `WITH TIES`, `OFFSET`, Oracle `ROWNUM`/`ROWID`, and
  Snowflake `WHERE` references to `SELECT` aliases are rejected.
- Joins: inner, left, right, full, and cross joins (including comma joins),
  with `ON` conditions or `USING` columns; table aliases, self-joins, chained
  joins, and `t.*`. Generated code declares each source table once and aliases
  joined tables so qualified columns resolve. Natural, semi, anti, and as-of
  joins, joins to subqueries, `LATERAL`/`APPLY`, and Oracle's `(+)` marker are
  rejected.
- Aggregation: `GROUP BY` columns and positions, `HAVING`, and `COUNT(*)`,
  `COUNT`, `COUNT(DISTINCT)`, `SUM`, `SUM(DISTINCT)`, `AVG`, `MIN`, `MAX`,
  including aggregate expressions. `HAVING` on aggregates not in the `SELECT`
  list uses helper columns that a final projection drops. Rejects columns that
  are neither grouped nor aggregated, ambiguous alias references, Oracle and
  T-SQL `GROUP BY` positions, and `ROLLUP`/`CUBE`/`GROUPING SETS`.
- Predicates and conditionals: `IN` lists, `BETWEEN`, `LIKE`/`ILIKE` with
  constant patterns, `IS [NOT] NULL`, NULL-safe equality, searched and simple
  `CASE`, `IF`/`IIF`, `COALESCE`/`IFNULL`/`NVL`, `NULLIF`, and
  `CAST`/`TRY_CAST`/`::` to an allowlist of types with the same meaning in
  every supported dialect. Rejects T-SQL `ISNULL`, T-SQL `VARCHAR` casts
  without a length, `FLOAT`/`REAL` casts, T-SQL `LIKE` character classes, and
  backslashes in `LIKE` patterns.
- String and numeric functions: `UPPER`, `LOWER`, `LENGTH`, `TRIM` variants,
  `SUBSTRING`, `CONCAT`, `||`, `REPLACE`, `LEFT`, `RIGHT`, `ABS`, `ROUND`,
  `CEIL`, `FLOOR`, `POWER`, `SQRT`, `SIGN`, `LN`, `LOG(base, x)`, `EXP`,
  `GREATEST`, `LEAST`. Emulates T-SQL `LEN`, MySQL byte-counting `LENGTH`, and
  NULL-skipping `CONCAT` exactly; rejects `ROUND` where floating-point halves
  round to even, NULL-propagating `GREATEST`/`LEAST`, ambiguous one-argument
  `LOG`, BigQuery `TRIM`, and non-constant or negative positions.
- Dates and timestamps: date parts, `CURRENT_DATE`/`CURRENT_TIMESTAMP`, day
  differences with each dialect's argument order, type-preserving date
  arithmetic in days, weeks, months, and years via `make_interval`, Spark's
  `DATE_ADD`/`DATE_SUB`, PostgreSQL and BigQuery `DATE_TRUNC`, and casts that
  map each dialect's timestamp types to Spark's `timestamp` (point in time) or
  `timestamp_ntz` (wall clock). Rejects seconds, weekdays, week numbers,
  non-day `DATEDIFF` units, input-type-preserving `DATE_TRUNC`, end-of-month
  `ADD_MONTHS`, T-SQL `DATETIME`/`SMALLDATETIME`/`TIMESTAMP`, and `SYSDATE`.
- Unaliased `SELECT` items that call functions now require an alias, because
  Spark names such columns after the original spelling.
- A `products` test table with whitespace, multi-byte text, and rounding
  boundaries.
- Generic IR child traversal, so checks such as "column is neither grouped nor
  aggregated" see inside every expression type.
- Equivalence testing for `LIMIT` without `ORDER BY` (row count plus
  sub-multiset of the unlimited result), and dialect scenarios checked against
  hand-written Spark SQL references.
- Long expressions are wrapped to fit 88 columns: one condition per line
  for `&`/`|` chains, one branch per line for `F.when`, one argument per
  line for long calls, and Black-style parentheses before `.alias`.
  Tests check that every equivalence scenario's code fits, and that
  wrapping never changes the Python syntax tree.
- `ORDER BY` on columns, aliases, positions, expressions, and aggregates, with
  `ASC`/`DESC` and `NULLS FIRST`/`NULLS LAST`. NULLs are placed as the
  source dialect does (PostgreSQL, Oracle, and Snowflake put them last when
  ascending). Keys that are not selected sort before the projection, or in
  aggregate queries through helper columns. Rejects aliases inside `ORDER BY`
  expressions, constants, ambiguous names, and keys outside a `SELECT
  DISTINCT` list.
- Ordered equivalence testing: rows that tie on the sort keys may come in any
  order, and a `LIMIT` may cut the last group of ties.
- Window functions: `ROW_NUMBER`, `RANK`, `DENSE_RANK`, and `COUNT`, `SUM`,
  `AVG`, `MIN`, `MAX` over `PARTITION BY` and `ORDER BY`, with SQL's default
  frame and each dialect's NULL placement. Each distinct window is declared
  once as a variable. Rejects explicit frames, other window functions,
  `IGNORE NULLS`, named windows, `DISTINCT` in windows, and windows outside
  the `SELECT` list or in aggregate queries.
- `LAG`, `LEAD`, `FIRST_VALUE`, `LAST_VALUE`, and `NTILE`, and explicit `ROWS`
  and `RANGE` window frames. `IGNORE NULLS` for `FIRST_VALUE` and
  `LAST_VALUE`. Snowflake's documented whole-window default for `FIRST_VALUE`
  and `LAST_VALUE` is written out as an explicit frame; BigQuery, whose
  default is undocumented, needs an explicit frame. Rejects `RANGE` offsets,
  `GROUPS` frames, `EXCLUDE`, and frames on ranking and offset functions.
- CTEs (`WITH`), including chained CTEs, CTEs used several times, CTEs that
  hide a table of the same name, column lists, and `WITH` inside
  subqueries; and subqueries in `FROM` and `JOIN`. Each becomes a variable
  declared once, in the order the code needs it. Rejects `WITH RECURSIVE`
  and set operations inside them.
- Set operations: `UNION`, `INTERSECT`, and `EXCEPT` (and `MINUS`), in
  their distinct and `ALL` forms, matched by position, with `ORDER BY` and
  `LIMIT` on the combined result, and inside CTEs and subqueries. Rejects
  `INTERSECT` mixed with `UNION` or `EXCEPT` without parentheses, since
  databases disagree on which runs first, and queries with different
  numbers of columns.
- Subqueries in expressions: `IN` and `NOT IN` as `WHERE` and `HAVING`
  conditions, `EXISTS`, `NOT EXISTS`, and subqueries used as values, in
  `WHERE`, `HAVING`, `ORDER BY`, and the `SELECT` list, including
  correlated subqueries. Translated with Spark's subquery methods, which
  keep SQL's NULL rules for `NOT IN`. Rejects `IN (subquery)` used as a
  value (Spark returns false where SQL returns NULL), `ANY`/`ALL`, and
  row-value `IN`.
- Command line: `sparkshift convert` (also `python -m sparkshift`) converts
  a SQL file, standard input, or every `.sql` file in a directory into a
  matching tree of `.py` files, with `--dialect` and `--output`. Code goes
  to standard output and messages to standard error, ending with a summary
  for a directory; the exit status is 0 when everything is converted, 1
  when anything cannot be, and 2 for usage errors.
- An examples gallery: a realistic query in each dialect with its generated
  PySpark, regenerated by the command line and checked by tests to match the
  converter's output and to return the same result as the SQL on Spark.
- A Package job in CI builds the wheel, checks that SQLGlot is its only
  runtime dependency and that it contains the package, type information,
  license, and command, checks the description with `twine`, and runs the
  installed `sparkshift` command in a clean environment.
- A web playground that runs SparkShift in the browser with Pyodide: a
  static page with no server, so SQL never leaves the browser (ADR 0004).
  A browser test in CI converts every example in headless Chromium and
  requires output identical to the command line's.
- The playground is published at https://arttgrantollii.github.io/sparkshift/ after CI passes
  on `main`. It can share a query as a link (kept after the `#`, so it is
  never sent to a server), highlights the generated code, and passes an
  axe-core accessibility audit (WCAG 2.1 AA) in light and dark mode.
- `QUALIFY` in generic SQL, Snowflake, and BigQuery: window functions and
  unselected columns it uses become helper columns of the projection, which
  are filtered on and then dropped, so it runs after the window functions and
  before `DISTINCT`, `ORDER BY`, and `LIMIT`. Rejected in dialects without
  `QUALIFY`, in aggregate queries, and, in Snowflake, when it names a `SELECT`
  alias, which Snowflake reads as a table column if one exists. A Snowflake
  example in the gallery shows it.
- `sparkshift report`: a coverage report for a SQL file or directory, as
  text, Markdown, or JSON. It gives every file one status (converted, with
  warnings, not converted, invalid SQL, or unreadable) and ranks the
  constructs that block conversion by the number of files they block, with
  hints and example files. `--fail-under PERCENT` makes it usable as a CI
  gate. A sample workload is in `examples/coverage`.
- PostgreSQL scenarios and examples also run on a real PostgreSQL 18 server
  in CI, compared with the generated PySpark on Spark, so the hand-written
  Spark SQL references are no longer the only check. The tests skip without
  a configured server, and fail instead of skipping in CI.
- MySQL scenarios and examples run on a real MySQL 8.4 server in CI too,
  through the same runner. The test database compares strings exactly, as
  Spark does, and MySQL's 0 and 1 compare as booleans.
- SAS front end (in progress; ADR 0005): `convert(program, dialect="sas")`
  and `sparkshift convert job.sas --dialect sas` convert DATA steps that read
  one data set with `SET`, filter it with `WHERE` or `WHERE=`, and keep, drop,
  or rename variables, in SAS's documented order. Conditions follow SAS's
  rules: a missing number is smaller than every number, a comparison is never
  missing, and trailing blanks do not count in text. Each data set becomes a
  DataFrame variable; `result` is the last. Everything else is rejected with
  every issue listed. SAS scenarios check the generated code on Spark against
  expected rows written by hand from the documented rules (docs/sas.md).
- `SASParseError`, a subclass of `SQLParseError`, for invalid SAS programs.
- SAS DATA step logic: assignments (in order, as `.withColumn`), arithmetic,
  `IF ... THEN ... ELSE` with `ELSE IF` chains and `DO; ... END;` blocks,
  subsetting `IF`, `DELETE`, and `LENGTH`. Following SAS: division by zero
  gives a missing value; a number alone is true unless 0 or missing; without
  `ELSE`, a new variable is missing and an input variable keeps its value; and
  a new text variable takes the length of its first value, so longer values
  are truncated, with a warning. Where the answer depends on input columns
  SparkShift cannot see, it uses what the program shows (a variable read
  before it is assigned, or `KEEP=` on the `SET` data set) or rejects the
  statement with a hint.
- SAS functions: `SUM`, `MEAN`, `MIN`, `MAX`, `N`, `NMISS`, `COALESCE`,
  `ROUND`, `INT`, `CEIL`, `FLOOR`, `ABS`, `MOD`, `UPCASE`, `LOWCASE`, `STRIP`,
  `TRIM`, `SUBSTR`, `LENGTH`, `CATS`, `CATX`, `COALESCEC`, and `MISSING`, each
  following its page in SAS's function reference: statistics skip missing
  values; `INT`, `CEIL`, and `FLOOR` treat a value within 1E-12 of an integer
  as that integer; `LENGTH` ignores trailing blanks and is 1 for blank text;
  `CATX` adds no delimiter for blank items; and text results get SAS's
  lengths (200 for `CATS` and `CATX`, which give a blank, not a truncated
  value, when the result does not fit). Function results are typed, so they
  work in conditions and comparisons. Other functions, `OF` variable lists,
  and arguments of the wrong type are rejected; `MOD` by a fraction is a
  review warning.
- SAS `PROC SORT`: `DATA=` (or the data set created last), `OUT=` (or the
  sorted data replaces the input), data set options, `WHERE`, `BY` with
  `DESCENDING`, and `NODUPKEY`, as `.dropDuplicates(...)` and `.orderBy(...)`.
  Missing values sort first, as SAS documents, and last with `DESCENDING`.
  `NODUPKEY` warns that Spark may keep any row of a BY group, not the first.
  Options that do not change the result are accepted; `DUPOUT=`,
  `NOUNIQUEKEY`, and collating sequences are rejected.
- `ir.DropDuplicates`, emitted as `.dropDuplicates([...])`.
- SAS `PROC MEANS` and `PROC SUMMARY` with `OUTPUT OUT=`: `CLASS`, `VAR`,
  `BY`, `WHERE`, `NWAY`, and `MISSING`, and the statistics `N`, `NMISS`,
  `SUM`, `MEAN`, `MIN`, `MAX`, `RANGE`, `STD`, and `VAR`. Following SAS:
  observations with a missing CLASS value are left out unless `MISSING`;
  without `NWAY`, every combination of the CLASS variables, as `.cube(...)`,
  with `_TYPE_` computed from `F.grouping_id()`; `_FREQ_` counts
  observations; `VAR` and `STD` divide by n − 1; the output is ordered by BY,
  `_TYPE_`, and CLASS. PROC MEANS without `OUTPUT`, quantiles, `AUTONAME`,
  and `TYPES`/`WAYS`/`ID`/`FREQ`/`WEIGHT` are rejected.
- IR: `Aggregate(cube=True)` (`.cube(...)`) and the aggregates `count_if`,
  `var_samp`, `stddev_samp`, and `grouping_id`.
- SAS `PROC FREQ` with `TABLES ... / OUT=`: one-way and n-way tables, `BY`,
  `WHERE`, `MISSING`, and `OUTPCT` for two-way tables. `COUNT` and
  `PERCENT` follow SAS: a combination with a missing value keeps its count
  but is left out of the percentages, unless `MISSING`; percentages are
  within BY groups (window sums); missing values come first in the order.
  PROC FREQ without `OUT=`, its `OUTPUT` statement, `SPARSE`, `OUTCUM`, and
  grouped requests are rejected.
- SAS `PROC SQL`: `CREATE TABLE ... AS SELECT` with `DISTINCT`, `AS` names,
  data set options in `FROM`, table aliases and `table.column`, `INNER` and
  `LEFT JOIN ... ON`, `WHERE`, `GROUP BY`, `HAVING`, `ORDER BY`, and
  summary functions (`COUNT(*)`, `COUNT`, `SUM`, `AVG`, `MIN`, `MAX`, ...).
  Conditions follow SAS's missing-value rules, as PROC SQL does: a missing
  value is smaller than any number, and a join matches missing values
  (`eqNullSafe`, with a warning about text). With two or more arguments,
  `SUM` and the others are the per-row DATA step functions. Remerging,
  subqueries, `CALCULATED`, set operators, other joins, and other statements
  are rejected.
- SAS everywhere SQL is: a `.sas` file is converted as SAS without
  `--dialect`; `convert` and `report` take the `.sas` files of a directory
  along with its `.sql` files (only the `.sas` files with `--dialect sas`),
  and the report names the languages; the playground has SAS in its dialect
  list and SAS examples; the examples gallery has three SAS programs, checked
  on Spark against rows written by hand. Phase 4 (SAS) is complete.
- Databricks notebooks (ADR 0007): `sparkshift convert --notebook` and
  `sparkshift.to_notebook(...)` write the generated code as a source-format
  notebook (`# Databricks notebook source`): a Markdown cell with the source,
  its language, and the warnings to review, one cell per section of the code,
  and `display(result)`. Every example, run as a notebook on Spark, displays
  the same rows as its code.
- Spark Connect testing: with `SPARKSHIFT_SPARK_MODE=connect` (and
  `uv sync --group connect`), every Spark test runs through a local Spark
  Connect server, as code runs on Databricks serverless compute. A new CI job,
  "Spark Connect", runs them on every push.
- `sparkshift upload PATH --to FOLDER` (ADR 0010): converts a `.sql`/`.sas`
  file or directory into notebooks and imports them into a Databricks
  workspace folder, keeping relative paths, with `--profile`, `--overwrite`,
  `--strict`, and `--dry-run`. Needs the new optional extra
  `sparkshift[databricks]` (the Databricks SDK); credentials come only from
  the SDK's environment variables or `~/.databrickscfg` profiles and are
  redacted from every message. `.env.example` documents the variables.
- Validation on Databricks: `tools/validate_databricks.py` uploads every
  example with `sparkshift upload`, runs them in a serverless job, and
  compares each result with local Spark. On a Free Edition workspace, all 11
  examples matched in serverless environments 4 (PySpark 4.0.0) and 5
  (PySpark 4.1.0); environments 2 and 3 have a PySpark 3.5 client, which
  lacks `Column.outer()`. Recorded in `docs/databricks-validation.md`.

### Changed

- Generated notebooks say in their first cell that the code needs a PySpark
  4 client: serverless environment version 4 or later. Phase 5 (Databricks)
  is complete.
- Release automation (ADR 0011): pushing a version tag runs every CI job,
  checks the tag against the version and the CHANGELOG, publishes to
  TestPyPI, installs it from there, and, after a maintainer's approval,
  publishes to PyPI with Trusted Publishing (no token) and creates a GitHub
  release. The PyPI description is the README with its relative links
  rewritten to GitHub. Package description and keywords now mention SAS and
  Databricks.
- Documentation: the README is now a front page (about 200 lines, down from
  630); the details moved, unchanged, into guides: `docs/supported-sql.md`,
  `docs/cli.md`, `docs/databricks.md`, and a new `docs/api.md` for the
  Python API. New `CONTRIBUTING.md` and `SECURITY.md`. A test checks that
  every relative link and anchor in the documentation resolves.
- Generated notebooks have `catalog` and `schema` widgets, text boxes at the
  top of the notebook that select where tables are read from, with the
  catalog API (names are never put into SQL text). `convert --notebook` and
  `upload` take `--catalog` and `--schema` for their initial values; empty
  keeps the current ones. Before, a notebook whose tables were in another
  schema failed with `TABLE_OR_VIEW_NOT_FOUND` unless the user added `USE`
  statements.

- Decimal literals are generated as their text cast to their exact type,
  `F.lit("1.10").cast("decimal(3,2)")`, instead of `F.lit(Decimal("1.10"))`,
  which Spark Connect types as `decimal(10,2)`. A decimal literal cast to a
  decimal type is cast once, straight from its text.

- `IN (subquery)` where no subquery is allowed, such as in `QUALIFY` or a
  join condition, now reports where subqueries are supported instead of
  "used as a value".
- Aggregation without `GROUP BY` is generated as `.select(...)` instead of
  `.agg(...)`: the same one-row result, and it also works in correlated
  subqueries, where Spark cannot resolve `.agg(...)`.
- Package metadata: development status Alpha, a Console environment
  classifier, and no `databricks` keyword until Databricks support exists.

### Fixed

- Reject SAS PROC SQL `GROUP BY` without a summary function in SELECT or HAVING.
  SAS treats it as sorting; previously generated aggregation silently removed
  duplicate rows. The error gives explicit ORDER BY / DISTINCT rewrite guidance.

- Keep every line of notebook metadata inside Markdown comments, including
  multiline source names and diagnostics containing notebook cell markers.
  Metadata can no longer add executable Python or extra notebook cells.


- Browser conversion runs in a module Web Worker, with cancellation on request
  or input changes, a 10-second conversion deadline and worker reload after
  interruption or crashes. Loading has a 120-second deadline and a retry action.
  Request IDs and input revisions prevent stale responses from restoring output.

- Directory conversion checks all selected output names before converting or
  writing, rejecting same-stem SQL/SAS files, case-only variants, and output
  file/directory conflicts with a usage error listing every conflicting mapping.
  A colliding batch writes no files; separate subfolders and SAS-only selection
  remain supported.

- The playground now shows conversion warnings, including SAS NODUPKEY's
  retained-row warning, and clears output and Copy availability on input edits
  or conversion failures. Unexpected Python/JSON failures and excessive nesting
  show readable errors; valid input can be converted again afterwards.
- The browser demo enforces a documented 50,000-byte UTF-8 source limit in
  JavaScript and the Python bridge. The CLI and Python API remain unrestricted
  by this demo policy. This is not an execution timeout or cancellation system.
- Correlated EXISTS queries omit output helper cleanup and DISTINCT, which
  cannot change row existence but can resolve outer references too early in
  Spark. Filters and limits are retained, including LIMIT 0.

- Generated helper columns now avoid user columns and aliases, including
  unknown schemas, case-insensitive collisions and nested query scopes.
  SAS IF helpers and wildcard QUALIFY helpers select unused names from the
  actual input schema at execution; aggregate helpers also reserve unselected
  grouping keys. Before, helpers could overwrite and drop data or make a
  valid query ambiguous.
- A SAS IF helper in a DATA step whose `SET` lists its columns with `KEEP=`
  now gets its name during conversion (`_if_1`, or `_if_1_2` when that name
  is taken), instead of generated code that looks up the input's column names
  when it runs. The lookup remains where the input's columns are unknown.
- SAS `LENGTH` statements now follow the program data vector. A variable
  declared but never assigned was missing from the output; SAS writes it as
  a missing column. A new variable declared before another one that is
  assigned first came out in the wrong column order. A `LENGTH` for an input
  variable named in `KEEP=` truncated its later values; SAS ignores it. With
  `KEEP=` on `SET`, the output now matches; without it, a never-assigned
  `LENGTH` variable is rejected and a different order is warned about.
- `CAST(x AS INT)` and other integer casts in PostgreSQL, MySQL, Snowflake,
  and BigQuery dropped the fraction, as Spark's cast does (`2.7` → `2`); these
  databases round (`3`). The generated code now rounds first,
  `F.round(x).cast("int")`, checked on real PostgreSQL and MySQL. Their
  floating-point halves round to even, which is documented as a limitation.
- SQL wildcard modifiers (`EXCEPT`/`EXCLUDE`, `REPLACE`, `RENAME`, `ILIKE`)
  are now rejected with rewrite guidance in projections and `COUNT(*)`,
  including qualified and nested queries. Previously they were silently
  discarded, retaining excluded columns, losing replacement calculations,
  or producing incorrect row counts.
- T-SQL `AVG(x)` is now rejected unless `x` is visibly a decimal or
  floating-point value, such as `AVG(CAST(x AS DECIMAL(10, 2)))`. T-SQL
  averages integers as an integer (the average of 1 and 2 is 1); the
  generated `F.avg` returned 1.5.
- `ROW_NUMBER`, `RANK`, and `DENSE_RANK` without `ORDER BY` in the window are
  now rejected; they produced code that Spark refuses to run.
- Long comparisons and arithmetic are now wrapped to fit 88 columns, one
  operand per line with the operator leading; before, a long comparison such
  as a date filter stayed on one line. A wrapped condition followed by a comma
  could also run one column over the limit.
- PostgreSQL `date + INTERVAL ...` was converted to a date; PostgreSQL returns
  a timestamp. It is now converted to a timestamp when the value is visibly a
  date (`CAST(x AS DATE)`, `DATE '...'`, `CURRENT_DATE`), keeps its type when
  visibly a timestamp, and is rejected for a column, whose type only the
  schema would tell.
